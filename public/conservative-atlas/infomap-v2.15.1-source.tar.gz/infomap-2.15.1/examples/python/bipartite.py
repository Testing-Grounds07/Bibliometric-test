from infomap import Infomap

im = Infomap(two_level=True)

# Set the start id for bipartite nodes
im.bipartite_start_id = 5

# Add weight as an optional third argument
im.add_link(5, 0)
im.add_link(5, 1)
im.add_link(5, 2)
im.add_link(6, 2, 0.5)
im.add_link(6, 3)
im.add_link(6, 4)

result = im.run()

print(
    f"Found {result.num_top_modules} modules with codelength "
    f"{result.codelength:.8f} bits"
)

print("\n#node module:")
for node, module in result.modules().items():
    print(node, module)
