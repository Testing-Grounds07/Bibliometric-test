"""The single boundary to the SWIG-compiled Infomap engine.

`Core` is a transparent proxy: it owns the one `InfomapWrapper` instance and
forwards every unknown attribute to it. Every other module in the package talks
to `Core`, never to `InfomapWrapper` directly, so the binding can later be
swapped (nanobind/pybind11) by rewriting only this file. Phase 1 preserves
behaviour exactly -- typed accessors and bulk extraction arrive in Phase 2.

The two module-level engine functions that are part of the public package
surface (``build_info`` and ``run`` — the ``python -m infomap`` CLI driver) are
re-exported here so the rest of the package reaches them through this single
boundary instead of importing the SWIG layer directly.
"""

from __future__ import annotations

from typing import Any

from ._bindings import InfomapIterator as InfomapIterator
from ._bindings import InfomapIteratorPhysical as InfomapIteratorPhysical
from ._bindings import InfomapLeafIterator as InfomapLeafIterator
from ._bindings import InfomapLeafIteratorPhysical as InfomapLeafIteratorPhysical
from ._bindings import InfomapLeafModuleIterator as InfomapLeafModuleIterator
from ._bindings import InfomapWrapper  # the only engine import

# Documented tree-walking iterator/node types returned by ``Infomap.tree`` /
# ``leaf_modules`` and the physical variants (source/api/iterators.rst). They are
# public API, so they're re-exported through this single boundary -- like
# ``build_info``/``run`` above -- for the facade to surface, rather than letting
# any other module import the SWIG layer. Raw/undocumented SWIG containers
# (vector_*, Config, StateNetwork, FlowModel, FlowData, ...) are deliberately
# NOT re-exported.
from ._bindings import InfoNode as InfoNode

# Engine log-sink hooks, re-exported through this single boundary for
# infomap._logging: install/remove the process-global line sink, and drain
# lines queued by non-GIL-holding threads after an engine call returns. Kept
# under their private (underscore) names so the re-export uses the redundant
# ``_x as _x`` alias a type checker treats as an explicit re-export -- a renamed
# alias reads as an unexported private symbol (pyright reportPrivateImportUsage).
from ._bindings import _drain_log_queue as _drain_log_queue
from ._bindings import _set_log_callback as _set_log_callback
from ._bindings import build_info as build_info  # module-level engine function
from ._bindings import run as run  # module-level engine function (CLI driver)
from .errors import _translate_engine_errors


def _with_owner(proxy, owner):
    """Keep `owner` alive for as long as `proxy` is reachable.

    The network accessors hand out a SWIG proxy over a C++ member of the wrapper, with
    thisown false and no lifetime tie declared anywhere in interfaces/swig. Once the
    owning object became unreachable the wrapper was deleted and every read through the
    proxy was a use-after-free -- silent when the freed page still held the old values,
    a segfault otherwise (#900).
    """
    proxy._infomap_owner = owner
    return proxy


class Core:
    def __init__(self, args):
        # Argument/config errors ("Unrecognized option: ...", option
        # conflicts) are thrown while the wrapper parses ``args``.
        with _translate_engine_errors():
            self._im = InfomapWrapper(args)
        # Flow model an input adapter resolved from the input itself (a
        # directed graph object, an explicit ``directed=`` on the matrix and
        # edge-index adapters). Recorded rather than set on the engine: see
        # note_inferred_flow_model.
        self.inferred_flow_model: str | None = None

    def note_inferred_flow_model(self, flow_model: str) -> None:
        """Record a flow model that an input adapter resolved from the input.

        Setting it on the engine directly does not survive a run: options reach
        the engine as a rendered argument string that it re-parses into a fresh
        config, so anything configured outside that string is dropped as soon as
        the string changes -- which any per-run keyword does. The recorded value
        is instead folded into the options that get rendered
        (``_with_inferred_flow_model``), so it is authoritative for every run.

        Explicit configuration wins. Nothing is recorded when the engine was
        constructed with a flow model, and the first inference wins over a later
        one so a second adapter call cannot silently change the model.
        """
        if self.flowModelIsSet or self.inferred_flow_model is not None:
            return
        self.inferred_flow_model = flow_model

    def get_node_data(self, level=1, states=False):
        """Single-traversal bulk node data over the result tree.

        Returns the SWIG ``NodeData`` snapshot of parallel columns
        (``node_id``, ``state_id``, ``module_id``, ``flow``, ``depth``,
        ``layer_id``, ``child_index``) plus the CSR-encoded ragged path
        (``path_flat`` + ``path_len``). The canonical bulk-extraction entry
        point for ``Result``; mirrors the iterator choice of the legacy
        per-node accessors.
        """
        return self._im.getNodeData(level, states)

    def __getattr__(self, name: str) -> Any:
        # Only called for attributes missing on Core itself. Guard against
        # recursion before _im exists (e.g. during unpickling/__new__).
        # The ``Any`` return models the dynamic forwarding proxy honestly: the
        # SWIG instance is untyped, so any forwarded ``core.<x>`` access is Any.
        if name == "_im":
            raise AttributeError(name)
        return getattr(self._im, name)


def _with_inferred_flow_model(core: Any, options):
    """Fold an adapter's inferred flow model into the options to be rendered.

    Shared by ``Infomap.run`` and ``Network.run`` so both entry points agree on
    the precedence: an inference (recorded by ``Core.note_inferred_flow_model``)
    applies only when this run's options carry neither ``flow_model`` nor
    ``directed``, so explicit configuration always wins -- whether it was given
    at construction, on the options carrier, or as a per-run keyword.

    Returns ``options`` unchanged when there is nothing to fold in.
    """
    inferred = getattr(core, "inferred_flow_model", None)
    if inferred is None:
        return options
    if options.flow_model is not None or options.directed is not None:
        return options
    return options.replace(flow_model=inferred)


def apply_initial_partition(core: Any, module_ids) -> bool:
    """Set an initial partition on ``core`` for the next run.

    Accepts ``{node_or_state_id: module_id}`` (integers) or, for a multilayer
    network, ``{(layer_id, node_id): module_id}``. Returns ``True`` when the
    multilayer form was applied. Shared by ``Infomap.initial_partition`` and
    ``Network.run`` so the validation/dispatch lives in one place.
    """
    if module_ids is None:
        module_ids = {}
    # Accept a dict (the documented form) or the SWIG map the engine
    # round-trips through here (getInitialPartition() returns a map_uint_uint,
    # not a dict); reject a non-mapping (a list, a scalar) up front with a clear
    # message instead of a raw SWIG TypeError from setInitialPartition.
    if not hasattr(module_ids, "items"):
        raise TypeError(
            "initial_partition must be a mapping of {node_id: module_id} "
            "(or {(layer_id, node_id): module_id} for a multilayer network), "
            f"not {type(module_ids).__name__}."
        )
    if module_ids and any(isinstance(key, tuple) for key in module_ids):
        if not all(isinstance(key, tuple) for key in module_ids):
            raise ValueError(
                "initial_partition keys must be either all integers "
                "(node/state ids) or all (layer_id, node_id) tuples, not mixed"
            )
        if not all(len(key) == 2 for key in module_ids):
            raise ValueError(
                "multilayer initial_partition keys must be (layer_id, node_id) "
                "2-tuples (or MultilayerNode)"
            )
        layer_ids, node_ids, modules = [], [], []
        for (layer_id, node_id), module in module_ids.items():
            layer_ids.append(int(layer_id))
            node_ids.append(int(node_id))
            modules.append(int(module))
        core.setMultilayerInitialPartition(layer_ids, node_ids, modules)
        return True
    # First-order path. Validate int-castability for a user dict (the engine's
    # own SWIG map is already integer-keyed and passes straight through) so a
    # malformed value -- e.g. a {node: (path,)} tuple -- raises a clear error
    # instead of a raw SWIG TypeError from setInitialPartition.
    if isinstance(module_ids, dict):
        try:
            module_ids = {int(node): int(module) for node, module in module_ids.items()}
        except (TypeError, ValueError) as exc:
            raise TypeError(
                "initial_partition must map integer node/state ids to integer "
                "module ids, e.g. {1: 0, 2: 0, 3: 1}."
            ) from exc
    core.setInitialPartition(module_ids)
    return False
