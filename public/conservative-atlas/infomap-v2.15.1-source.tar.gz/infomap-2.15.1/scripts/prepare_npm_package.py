#!/usr/bin/env python3

import argparse
import json
import shutil
from pathlib import Path

KEEP_PACKAGE_FIELDS = [
    "name",
    "version",
    "description",
    "browser",
    "module",
    "publishConfig",
    "files",
    "main",
    "types",
    "type",
    "exports",
    "bin",
    "sideEffects",
    "repository",
    "keywords",
    "author",
    "maintainers",
    "license",
    "bugs",
    "homepage",
    "peerDependencies",
    "peerDependenciesMeta",
]


def copy_file(source, target_dir, target_name=None):
    source_path = Path(source)
    target_path = Path(target_dir) / (target_name or source_path.name)
    shutil.copy2(source_path, target_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-package", default="package.json")
    parser.add_argument("--readme", default="interfaces/js/README.md")
    parser.add_argument("--readme-rst", default="README.rst")
    parser.add_argument("--license", default="LICENSE_GPLv3.txt")
    parser.add_argument(
        "--node-module",
        help="Emscripten Node library artifact to stage (infomap.node.mjs).",
    )
    parser.add_argument(
        "--cli-module",
        help="Emscripten Node bin artifact to stage (infomap.cli.mjs).",
    )
    parser.add_argument("--output-dir", default="dist/npm/package")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    source_package = json.loads(Path(args.source_package).read_text(encoding="utf-8"))
    staged_package = {
        key: source_package[key] for key in KEEP_PACKAGE_FIELDS if key in source_package
    }
    (output_dir / "package.json").write_text(
        json.dumps(staged_package, indent=2) + "\n", encoding="utf-8"
    )

    copy_file(args.readme, output_dir, "README.md")
    copy_file(args.readme_rst, output_dir, "README.rst")
    copy_file(args.license, output_dir, "LICENSE_GPLv3.txt")

    if args.node_module:
        copy_file(args.node_module, output_dir)
    if args.cli_module:
        copy_file(args.cli_module, output_dir)


if __name__ == "__main__":
    main()
