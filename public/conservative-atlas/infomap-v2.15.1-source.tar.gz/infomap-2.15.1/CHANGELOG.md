# Changelog

All notable changes to this project will be documented in this file. Releases are automated with [release-please](https://github.com/googleapis/release-please), using [Conventional Commits](https://www.conventionalcommits.org) to determine version bumps and changelog entries.

## [2.15.1](https://github.com/mapequation/infomap/compare/v2.15.0...v2.15.1) (2026-08-04)


### Bug Fixes

* configure the super-level objective from the run, not from defaults ([#955](https://github.com/mapequation/infomap/issues/955)) ([497d86b](https://github.com/mapequation/infomap/commit/497d86b642b61285aaf786a1701817640199d3fc))
* honor an explicit single-trial cap for --converge ([#928](https://github.com/mapequation/infomap/issues/928)) ([7ff63d1](https://github.com/mapequation/infomap/commit/7ff63d168868cad63acc3cce9bbcf72539795541))
* **js:** stop dropping per-run args and returning the input as Infomap's output ([#951](https://github.com/mapequation/infomap/issues/951)) ([1811d5c](https://github.com/mapequation/infomap/commit/1811d5c675040d95aa7521cb6d6c0647006ce22f))
* keep a rejected argument off stdout when the caller asked for silence ([#940](https://github.com/mapequation/infomap/issues/940)) ([0d949eb](https://github.com/mapequation/infomap/commit/0d949eb0544cc0143c9550af5e0cca69ca9d9c9b))
* keep output artifacts readable and say when a tree cannot be read back ([#952](https://github.com/mapequation/infomap/issues/952)) ([8cbf0f8](https://github.com/mapequation/infomap/commit/8cbf0f8eee8e22a8993cc54a9374ee3a857828db))
* keep the memory codelength scalar in sync with the module map ([48a1ef5](https://github.com/mapequation/infomap/commit/48a1ef565d287b0181a251d4f1a1f1fca930d0d7)), closes [#836](https://github.com/mapequation/infomap/issues/836)
* let the entropy-bias correction reach the move loop ([#922](https://github.com/mapequation/infomap/issues/922)) ([eb0c444](https://github.com/mapequation/infomap/commit/eb0c4445aa696f2135c8fd1f5af6c8467b7dde7e))
* make distributed runs publishable, verifiable and interruptible ([#953](https://github.com/mapequation/infomap/issues/953)) ([24cf348](https://github.com/mapequation/infomap/commit/24cf348c6192aae69f99380b33f6b9ba94670360))
* **python:** accept os.PathLike consistently across file-reading entry points ([#809](https://github.com/mapequation/infomap/issues/809)) ([db5b960](https://github.com/mapequation/infomap/commit/db5b9605867f26c4cf6d4041c277cdedc2160c0e))
* **python:** consolidate the file-path contract across all surfaces ([#811](https://github.com/mapequation/infomap/issues/811)) ([1a325b6](https://github.com/mapequation/infomap/commit/1a325b6a3545af503af8636ca1148031d364e59d))
* **python:** keep an adapter's inferred flow model across option rendering ([#916](https://github.com/mapequation/infomap/issues/916)) ([ad315fd](https://github.com/mapequation/infomap/commit/ad315fde9ed9b50d9eb8818ae17e27e243ea01e6))
* **python:** let an explicit keyword override the options carrier at its default ([#921](https://github.com/mapequation/infomap/issues/921)) ([01b73d3](https://github.com/mapequation/infomap/commit/01b73d32c9698639b07134f038f368890becee03))
* **python:** name the engine that went stale, and drop a remedy that reproduces the error ([#931](https://github.com/mapequation/infomap/issues/931)) ([fbefec2](https://github.com/mapequation/infomap/commit/fbefec24d31b8a606a94c0f878e3be74e8e8532b))
* read the list form of OMP_NUM_THREADS and give the thread ICV back ([#929](https://github.com/mapequation/infomap/issues/929)) ([823b93f](https://github.com/mapequation/infomap/commit/823b93f2fce182eac63b6b098d03a40eeb5de48b))
* redistribute dangling flow on bipartite input in the directed model ([#945](https://github.com/mapequation/infomap/issues/945)) ([cf5d59c](https://github.com/mapequation/infomap/commit/cf5d59cfd8d7291fcd9b0f195f55d800081cd990))
* refuse a run whose module flow went negative ([#963](https://github.com/mapequation/infomap/issues/963)) ([ff32bd8](https://github.com/mapequation/infomap/commit/ff32bd8c25c0d46cc19a74e3d317da7c03249f35))
* refuse bipartite teleportation without return links and report flow convergence ([#950](https://github.com/mapequation/infomap/issues/950)) ([89a98e2](https://github.com/mapequation/infomap/commit/89a98e20c7a5c26e0db3a9309d8af04fb588fff9))
* refuse to write output over the run's own input ([#927](https://github.com/mapequation/infomap/issues/927)) ([230c263](https://github.com/mapequation/infomap/commit/230c263049f3f93fc226aefd9b1cce1d3d986c41))
* reject a degenerate flow distribution instead of reporting codelength 0 ([#917](https://github.com/mapequation/infomap/issues/917)) ([940a320](https://github.com/mapequation/infomap/commit/940a320d653d5ce29694695a20ba168f371af899))
* reject intake values that were silently reinterpreted as another network ([#942](https://github.com/mapequation/infomap/issues/942)) ([899ffcf](https://github.com/mapequation/infomap/commit/899ffcfad07a5594fc00989e1caf88f51aabe9c9))
* **R:** validate node, state and layer ids instead of coercing them ([#918](https://github.com/mapequation/infomap/issues/918)) ([399a069](https://github.com/mapequation/infomap/commit/399a0695904a06ced20b99aa98f65c9010f5526b))
* seed every trial the same way, in every mode ([#949](https://github.com/mapequation/infomap/issues/949)) ([86116d7](https://github.com/mapequation/infomap/commit/86116d74f825e87d65380660457dfb2fc9af596a))
* stop handing Python and R objects that outlive the memory they point at ([#954](https://github.com/mapequation/infomap/issues/954)) ([6748dd6](https://github.com/mapequation/infomap/commit/6748dd66297fd6b390afa09a98bd897d96fb0bb1))
* stop R and JS rendering option values the argument string cannot carry ([#936](https://github.com/mapequation/infomap/issues/936)) ([c1b126b](https://github.com/mapequation/infomap/commit/c1b126b382913024ed32ba76d790bf04d025bc51))
* stop the bipartite flow adjustment leaving negative enter/exit flow ([#961](https://github.com/mapequation/infomap/issues/961)) ([fd2ddcd](https://github.com/mapequation/infomap/commit/fd2ddcde6614c39629347a7cc8ee7d76d9d6c0ae))
* validate cluster-data tree shape and node membership before using it ([#948](https://github.com/mapequation/infomap/issues/948)) ([d55c236](https://github.com/mapequation/infomap/commit/d55c2365051a282f309043ee69425b5c19fb562b))
* warn when the objective cannot apply a configured option ([#956](https://github.com/mapequation/infomap/issues/956)) ([5aa854f](https://github.com/mapequation/infomap/commit/5aa854f3cadbe6509f9727fc48413a2836e8ba31))


### Performance Improvements

* hoist per-node-constant plogp out of the OO move-loop delta ([7da08cf](https://github.com/mapequation/infomap/commit/7da08cfbd37063993fcc2f6b8b2978b91ac3745c)), closes [#867](https://github.com/mapequation/infomap/issues/867)

## [2.15.0](https://github.com/mapequation/infomap/compare/v2.14.0...v2.15.0) (2026-07-13)


### Features

* add a pluggable RNG seam for native embedders ([#423](https://github.com/mapequation/infomap/issues/423)) ([54103bd](https://github.com/mapequation/infomap/commit/54103bde73a492f6510c8e73e26cf6093076ef10))
* add infomap-network v1.0 JSON input format ([#645](https://github.com/mapequation/infomap/issues/645)) ([#668](https://github.com/mapequation/infomap/issues/668)) ([a15e3c4](https://github.com/mapequation/infomap/commit/a15e3c47966dea0dd2be40c4b48f03cc21e6748b))
* allow naming state nodes via addStateNode, wire through Python/R ([#799](https://github.com/mapequation/infomap/issues/799)) ([0638d54](https://github.com/mapequation/infomap/commit/0638d54a6aab8604fcb4c565082187e673514980))
* expose max/min flow iterations and flow tolerance in the API ([#764](https://github.com/mapequation/infomap/issues/764)) ([3a4b868](https://github.com/mapequation/infomap/commit/3a4b86878fdcf7aff033766d89011cb11b1b1907))
* **python:** accept an options= carrier on the graph community finders ([e4d2f1f](https://github.com/mapequation/infomap/commit/e4d2f1f7217553f5e041a4368db76c87cb00ebfe))
* **python:** accept an options= carrier on the stateful Infomap ([d127c87](https://github.com/mapequation/infomap/commit/d127c87b33d29301d3459f2e01bd2772b2829db4))
* **python:** add infomap.datasets with the bundled example networks ([#712](https://github.com/mapequation/infomap/issues/712)) ([3e083f3](https://github.com/mapequation/infomap/commit/3e083f3578a03a88a039fca4bd43cf7c1a634d76))
* **python:** add Result.summary() and Result.to_series() ([#783](https://github.com/mapequation/infomap/issues/783)) ([8ddd19d](https://github.com/mapequation/infomap/commit/8ddd19dd1fd207cb558e36560d09f7a6be400755))
* **python:** add Result.to_networkx and Result.to_igraph methods ([8e56bf2](https://github.com/mapequation/infomap/commit/8e56bf235d4b54c061a21c5d6abf9ab781682609))
* **python:** add signature-tier metadata to the parameter catalog ([#751](https://github.com/mapequation/infomap/issues/751)) ([f7451bb](https://github.com/mapequation/infomap/commit/f7451bbb4afa25eaff90069912c79da1e6fefe56))
* **python:** close builder/data-model gaps and type the Infomap facade ([b09384f](https://github.com/mapequation/infomap/commit/b09384f2ecdc86e47fd2b112f33abe60ac08d83b))
* **python:** emit type annotations on the generated Infomap signatures ([#752](https://github.com/mapequation/infomap/issues/752)) ([46883c8](https://github.com/mapequation/infomap/commit/46883c8ab9ea69bace9e278360251e803389e273))
* **python:** file writers on Result and Network ([#766](https://github.com/mapequation/infomap/issues/766)) ([e4537cf](https://github.com/mapequation/infomap/commit/e4537cfa754e306c7aa3a351fd746ad632d875b6))
* **python:** guard run() inputs, validate initial_partition, advise on Network logging ([b84c3b2](https://github.com/mapequation/infomap/commit/b84c3b2872a9348b3a94d9571e09229f2938f6b3))
* **python:** make infomap.run the canonical run entry point ([0210c27](https://github.com/mapequation/infomap/commit/0210c2728e45d78c165a98be07a33c59aef05969))
* **python:** mark non-engine Options fields in the generated docstring ([3fa4176](https://github.com/mapequation/infomap/commit/3fa4176d0d00b46e476c95f0d00c965b58c15f3a))
* **python:** public io namespace, tl re-exports, and API consistency cleanups ([f73e5dc](https://github.com/mapequation/infomap/commit/f73e5dc56a0bd5b282abedf8dcc9bc39cb52bb6c))
* **python:** render the Infomap summary card as Result._repr_html_ ([1764c05](https://github.com/mapequation/infomap/commit/1764c05eec765143362a13a059e1fb7a8c129bb1))
* **python:** route the engine log through Python logging ([#763](https://github.com/mapequation/infomap/issues/763)) ([182fc6a](https://github.com/mapequation/infomap/commit/182fc6ad911a352729cdf0ff117d20c21a6d63c3))
* **python:** sand down Result/Network agent-usability edges ([9cfb82d](https://github.com/mapequation/infomap/commit/9cfb82d27ae490a401c7bb0295271d01a5d4f072))
* **python:** steer Options errors and publish a machine-readable option catalog ([08f1911](https://github.com/mapequation/infomap/commit/08f191177ed8ada9656a6d82500e1c397e0fa2f2))
* **python:** surface the common-tier options on the run() signature ([4354fe0](https://github.com/mapequation/infomap/commit/4354fe08233ed6aa7281612166b397c16765a1c2))
* **python:** type the Network builder; ship py.typed in the sdist ([be70823](https://github.com/mapequation/infomap/commit/be70823d78e275166ab4cc1519fff51dad663802))
* **python:** validate numeric options against the catalog's ranges ([d50903a](https://github.com/mapequation/infomap/commit/d50903a0cd58d097bc90d984c2d78740a67b2539))
* **python:** validate option values and steer agents off usability traps ([450efce](https://github.com/mapequation/infomap/commit/450efce0fc3bf6f8dce206b969ca0072af38e9c7))
* **python:** warn on legacy instance accessors; clearer empty-network error ([d731321](https://github.com/mapequation/infomap/commit/d7313213426a8d911f75be91962149b7a9b7f51f))
* **python:** warn when args-only output options can't take effect ([b4c30aa](https://github.com/mapequation/infomap/commit/b4c30aa26daa64453fa5b3e87c6e3f5b57152878))
* **python:** widen num_threads to str | int | None via a types override ([0ebf437](https://github.com/mapequation/infomap/commit/0ebf437fb786d8597c05df9f2c381e841b385466))


### Bug Fixes

* honor --max-flow-iterations in regularized multilayer flow ([94905a7](https://github.com/mapequation/infomap/commit/94905a7da3144e2801443d1583a68c9431d50d7d))
* **python:** align and tidy the graph-library adapter surface ([90cebe0](https://github.com/mapequation/infomap/commit/90cebe0b9b7e417696fce331395a3d28a68779b9))
* **python:** attribute the export mismatch warning to the caller; unify two error types ([72dacf2](https://github.com/mapequation/infomap/commit/72dacf293910de5bac4a5404f1944f4bc4d36746))
* **python:** correct error types, path handling, and duplicated helpers ([6149487](https://github.com/mapequation/infomap/commit/61494879d946934c54f120b839ac71d19a3ed055))
* **python:** correct factual slips surfaced by the API review ([9472b69](https://github.com/mapequation/infomap/commit/9472b69180941d5547bf793125935c28557253e2))
* **python:** correct hide_bipartite_nodes docs and surface random-move defaults ([4a3bb7e](https://github.com/mapequation/infomap/commit/4a3bb7ef78f87b6d43f1beb955c563dd1cc2b9a0))
* **python:** correct the binding_default return annotation ([1087300](https://github.com/mapequation/infomap/commit/1087300c3fa70acd0d3dc5fe43beb6ff478168b6))
* **python:** don't flag a 2x2 array as a dense adjacency matrix ([132d754](https://github.com/mapequation/infomap/commit/132d7546a95c30c02008e249066756f39855086a))
* **python:** don't flag verbosity_level inert under routed DEBUG logging ([25d588a](https://github.com/mapequation/infomap/commit/25d588a583dace77647e560c2e2e5612dac82ea5))
* **python:** don't warn that hide_bipartite_nodes is inert ([4406f21](https://github.com/mapequation/infomap/commit/4406f212727ae3d99596d362964ce3fdf37572f7))
* **python:** emit a runtime deprecation warning on the legacy Infomap methods ([31903e7](https://github.com/mapequation/infomap/commit/31903e73de670f6162c9d4adfd687f504bc31e99))
* **python:** emit the advanced-tier deprecation warning from infomap.run() ([4c9d394](https://github.com/mapequation/infomap/commit/4c9d394fa2cb04aa8e60f81135285152bc897707))
* **python:** extend Result legacy-accessor hints to camelCase spellings ([c32c17e](https://github.com/mapequation/infomap/commit/c32c17e5d6104a41f17a0929971322a8f0ced989))
* **python:** import pandas lazily to avoid OpenMP duplicate-runtime abort ([#709](https://github.com/mapequation/infomap/issues/709)) ([eaffa4a](https://github.com/mapequation/infomap/commit/eaffa4a481f8164b5067eaabe36d3a0cab80a5b1))
* **python:** keep native attribute types in to_networkx and to_igraph ([7c1b31b](https://github.com/mapequation/infomap/commit/7c1b31b0db284acb381a193b42ce26649590db99))
* **python:** keep the option generator in sync with the directed/flow_model fix ([9822347](https://github.com/mapequation/infomap/commit/98223472e002022314853e00894d73dc6bc11e44))
* **python:** make the Python API silent by default ([#735](https://github.com/mapequation/infomap/issues/735)) ([a53c0a6](https://github.com/mapequation/infomap/commit/a53c0a657763163971c970ec2103c4b6393d4e1c))
* **python:** only warn on a real directed/flow_model conflict ([34ff4c6](https://github.com/mapequation/infomap/commit/34ff4c6ba1dda683634aa392a9642985f52bb133))
* **python:** re-export engine log hooks under their private names ([c88f7ea](https://github.com/mapequation/infomap/commit/c88f7eac0300ee283cc4b7b2856de20a974664ad))
* **python:** redirect legacy accessors on Result; correct the directed docs ([689d97f](https://github.com/mapequation/infomap/commit/689d97f650b42cbe5a1e5905042a96c33ea8e936))
* **python:** regenerate JS parameter metadata and address review comments ([56b223c](https://github.com/mapequation/infomap/commit/56b223c17b38802c757163fe12e79b302cbd9345))
* **python:** resolve API review findings ([f793470](https://github.com/mapequation/infomap/commit/f793470c28188c294b6e6397506b9b9e826b4306))
* **python:** route result.py iterator types through _core, not _swig ([2bcc2be](https://github.com/mapequation/infomap/commit/2bcc2beb9b3319f6e185841ac6f08ac87c28de80))
* **python:** sharpen run() front-door warnings and error messages ([01f1f4c](https://github.com/mapequation/infomap/commit/01f1f4c1ea46e17631ee22ba015c671ec3bebb59))
* **python:** sharpen two error surfaces on the run/result API ([4830216](https://github.com/mapequation/infomap/commit/48302163ca137c5fabaa1193a751451989febb08))
* **python:** stop the default Result read path nagging and trim guard lectures ([9e01007](https://github.com/mapequation/infomap/commit/9e0100776dec4890c4966450eebad3a815224dbc))
* **python:** turn agent-facing run/Network/Result footguns into guided errors ([9a9723f](https://github.com/mapequation/infomap/commit/9a9723fbc3d73506852cf9c60812df625209e1a8))
* **python:** validate the choices and bindingOnly override sections ([412f1c8](https://github.com/mapequation/infomap/commit/412f1c8b0ea251c057f7ef70c88d2a6639382fcb))
* **python:** warn on deprecated pretty and attribute option warnings to user code ([894c628](https://github.com/mapequation/infomap/commit/894c628c2c2ff28c5de2755bf8fa26d01809cab0))
* **python:** warn once per Network that its engine is silent for life ([3a72905](https://github.com/mapequation/infomap/commit/3a72905ab0175326ad0ab4787929ff54cb142764))
* **python:** warning and logging behavior for the 3.0 deprecation surface ([d49061f](https://github.com/mapequation/infomap/commit/d49061fc95042bbfbfbc1234fd1bccf056b5c246))


### Performance Improvements

* **python:** compute effective-num-modules lazily in Result ([#701](https://github.com/mapequation/infomap/issues/701)) ([c147cb0](https://github.com/mapequation/infomap/commit/c147cb0ba4561d41790f0743e529d2d390416de4))


### Reverts

* C++17 follow-up refactors ([#725](https://github.com/mapequation/infomap/issues/725)–[#730](https://github.com/mapequation/infomap/issues/730)) ([#731](https://github.com/mapequation/infomap/issues/731)) ([094ba1f](https://github.com/mapequation/infomap/commit/094ba1f9f8e0a8ccd6a6d381c9775193f30c3322))

## [2.14.0](https://github.com/mapequation/infomap/compare/v2.13.0...v2.14.0) (2026-06-30)


### Features

* expose state node names in Python and R results ([#700](https://github.com/mapequation/infomap/issues/700)) ([37e0854](https://github.com/mapequation/infomap/commit/37e085457338979a0390e36ac6411c68908bbc20)), closes [#699](https://github.com/mapequation/infomap/issues/699)
* **python:** redesign the Python API — Network, Result, Options, functional run() ([#694](https://github.com/mapequation/infomap/issues/694)) ([459d786](https://github.com/mapequation/infomap/commit/459d786ad5ce9fd2f71afaad57e6f64c8ff1b1ef))


### Bug Fixes

* reject ill-defined link weights at ingestion ([#698](https://github.com/mapequation/infomap/issues/698)) ([c2696a1](https://github.com/mapequation/infomap/commit/c2696a180a0436a4dfc1f830765ea912fe92432c))

## [2.13.0](https://github.com/mapequation/infomap/compare/v2.12.0...v2.13.0) (2026-06-23)


### Features

* add --multilayer-relax-to-self compact multilayer coupling ([#684](https://github.com/mapequation/infomap/issues/684)) ([7603a3f](https://github.com/mapequation/infomap/commit/7603a3f4c1766127fb1353752e2ffac0b5cbc76d))
* add cooperative interrupt hooks for long-running runs ([#682](https://github.com/mapequation/infomap/issues/682)) ([646a986](https://github.com/mapequation/infomap/commit/646a986b5a5b5601fc3871150b262de63ebb2278))
* add soft --preferred-number-of-levels depth preference ([#678](https://github.com/mapequation/infomap/issues/678)) ([e536f22](https://github.com/mapequation/infomap/commit/e536f2221c494b461a215fdf568cf4e2ad428cef))
* **js:** add Node.js build for testing and JS pipeline ([#686](https://github.com/mapequation/infomap/issues/686)) ([5781d9f](https://github.com/mapequation/infomap/commit/5781d9ffcbeef433834162c1822aab6f6df03803)), closes [#685](https://github.com/mapequation/infomap/issues/685)
* lossy map equation with noise modules (feature-flagged) ([#656](https://github.com/mapequation/infomap/issues/656)) ([ab1301f](https://github.com/mapequation/infomap/commit/ab1301f99df5c32f0203c8edc78745463cfd329c))
* multilayer cluster-data in the Python/R API ([#661](https://github.com/mapequation/infomap/issues/661)) ([39478a4](https://github.com/mapequation/infomap/commit/39478a467b3ebd8c9f89231a5611dcc93e5e2dde))
* stop trials on a codelength plateau with --converge ([#666](https://github.com/mapequation/infomap/issues/666)) ([474c6ca](https://github.com/mapequation/infomap/commit/474c6caf7c18f42e495ee65e45bd4f3efd468cf2))
* use pretty console output and migrate to fmt ([#648](https://github.com/mapequation/infomap/issues/648)) ([6179e00](https://github.com/mapequation/infomap/commit/6179e00a5a20dc1063312da713e2653e80538d4d))


### Bug Fixes

* correct lossy map equation for reciprocal links and one-level reference ([#669](https://github.com/mapequation/infomap/issues/669)) ([4cddf5d](https://github.com/mapequation/infomap/commit/4cddf5dc263789671ef0dcf1b7cbbbf02f04b59d))
* repair InfoNode API mismatch in materialize-and-free ([4d57aff](https://github.com/mapequation/infomap/commit/4d57aff0797e85e14ce343563acf097c7aca23ca))


### Performance Improvements

* arena-pool allocation for InfoNode/InfoEdge in InfomapBase ([#650](https://github.com/mapequation/infomap/issues/650)) ([f5f93ea](https://github.com/mapequation/infomap/commit/f5f93eaf7ecf445e44ff34fe4337e26bdcdf526e))
* build multilayer networks directly into CSR link storage ([#680](https://github.com/mapequation/infomap/issues/680)) ([b26c71b](https://github.com/mapequation/infomap/commit/b26c71b14804596e92b7b7d29d8540708d5fd19d))
* CSR link storage for ordinary and state network construction ([#670](https://github.com/mapequation/infomap/issues/670)) ([94d5cba](https://github.com/mapequation/infomap/commit/94d5cba56a33c189c76ed34674b838c8f1e74bc3))
* flatten the physical-node module maps to sorted vectors ([#653](https://github.com/mapequation/infomap/issues/653)) ([a6cdb66](https://github.com/mapequation/infomap/commit/a6cdb66c82cfa62528b191937d07597d98bc55ed))
* key the parse link maps by state id instead of StateNode ([#654](https://github.com/mapequation/infomap/issues/654)) ([05cadfc](https://github.com/mapequation/infomap/commit/05cadfcd4b4596c71cf6b53c856f8ecb29096c3b))
* materialize-and-free sub-Infomap working sets ([#660](https://github.com/mapequation/infomap/issues/660)) ([c82cb51](https://github.com/mapequation/infomap/commit/c82cb51a46dab0c4092e6cebf1c087cf2dc048a5))
* move InfoNode feature-only fields out-of-line ([#659](https://github.com/mapequation/infomap/issues/659)) ([b25099f](https://github.com/mapequation/infomap/commit/b25099f73715c08fbfe06d5b0238d1dbb7f95f27))
* replace level-synchronous recursion with a task graph ([#651](https://github.com/mapequation/infomap/issues/651)) ([fc5156d](https://github.com/mapequation/infomap/commit/fc5156d24f46b8f11ba48208bac5fc939e54ed10))
* reuse move-sweep buffers and rebuild the inner-parallel commit ([#652](https://github.com/mapequation/infomap/issues/652)) ([ab3c2db](https://github.com/mapequation/infomap/commit/ab3c2db2abbbe308968ae18b4811a6ee39903384))

## [2.12.0](https://github.com/mapequation/infomap/compare/v2.11.0...v2.12.0) (2026-06-08)


### Features

* --num-threads auto resolving cpuset / SLURM / OMP ([#634](https://github.com/mapequation/infomap/issues/634)) ([1f7718b](https://github.com/mapequation/infomap/commit/1f7718b8684bd59ed55b511b066dadbe3061c934))
* add run JSON reports ([#629](https://github.com/mapequation/infomap/issues/629)) ([1eff104](https://github.com/mapequation/infomap/commit/1eff1048ea2ce591a5a3288d2582d1ae1909c249))
* batch-safe output and reproducible run metadata ([#625](https://github.com/mapequation/infomap/issues/625)) ([#630](https://github.com/mapequation/infomap/issues/630)) ([013f17a](https://github.com/mapequation/infomap/commit/013f17a15ad9063f0bd088ea02b681ff29878059))
* distributed trial sharding (--trial-offset / --trial-results) ([#635](https://github.com/mapequation/infomap/issues/635)) ([b432bb8](https://github.com/mapequation/infomap/commit/b432bb896e99569aa0559d249e00bb6811f44c4e))
* **python:** add GraphRAG adapter ([#637](https://github.com/mapequation/infomap/issues/637)) ([898dbe3](https://github.com/mapequation/infomap/commit/898dbe360db7e70f20a7b973fd8876a5e19de83c))
* run independent trials concurrently with --parallel-trials ([#628](https://github.com/mapequation/infomap/issues/628)) ([5df160e](https://github.com/mapequation/infomap/commit/5df160e4fbcc2551ec529625a165fde25e14c5b9))


### Bug Fixes

* stabilize inner parallelization ([#594](https://github.com/mapequation/infomap/issues/594)) ([0c927f9](https://github.com/mapequation/infomap/commit/0c927f9b52288a25cc0d30edc6ee9c92102f359a))


### Performance Improvements

* cut multi-trial peak memory ~40% and shrink hot-path value types ([#622](https://github.com/mapequation/infomap/issues/622)) ([48d2843](https://github.com/mapequation/infomap/commit/48d2843cfc9d76e1023b3037b1bcdd0c7a28d3c1))

## [2.11.0](https://github.com/mapequation/infomap/compare/v2.10.1...v2.11.0) (2026-05-28)


### Features

* add shell completion generation ([#529](https://github.com/mapequation/infomap/issues/529)) ([82de4e4](https://github.com/mapequation/infomap/commit/82de4e4e435be2dbcaba60c9acff7669f2226c6f))
* pretty CLI output ([#568](https://github.com/mapequation/infomap/issues/568)) ([cb23d9f](https://github.com/mapequation/infomap/commit/cb23d9feee9a75816d58c9861fda36b02939a7b8))
* **python:** add AnnData Scanpy integration ([#549](https://github.com/mapequation/infomap/issues/549)) ([cc0fae4](https://github.com/mapequation/infomap/commit/cc0fae43be51a595b9c11c2af225261d906d5b71))
* **python:** add edge index input support ([#548](https://github.com/mapequation/infomap/issues/548)) ([0a5c74b](https://github.com/mapequation/infomap/commit/0a5c74b20073c4d6c73ca619f3c2d485d5748fbf))
* **python:** add GraphML and GEXF export helpers ([#550](https://github.com/mapequation/infomap/issues/550)) ([11f9395](https://github.com/mapequation/infomap/commit/11f93959d3f83d44b8ce10cce872bf4f63987a30))
* **python:** add igraph helpers ([#528](https://github.com/mapequation/infomap/issues/528)) ([efe1aa9](https://github.com/mapequation/infomap/commit/efe1aa99ea4dab33bfa027b43fb6dd4eb76c376c))
* **python:** add integration extras and typed marker ([8657773](https://github.com/mapequation/infomap/commit/8657773d6300007e5324fa6e9f089e8ee67092c2))
* **python:** add NetworkX-friendly find_communities() ([#525](https://github.com/mapequation/infomap/issues/525)) ([1b56af4](https://github.com/mapequation/infomap/commit/1b56af421374f8fdced22c32c1f2f5fd11dee547))
* **python:** add Python quickstart notebook and infomap-shell ([#601](https://github.com/mapequation/infomap/issues/601)) ([a864231](https://github.com/mapequation/infomap/commit/a864231e4c854e7e88cfee52e6b606061fa13a2f))
* **python:** add scipy sparse matrix support ([#547](https://github.com/mapequation/infomap/issues/547)) ([fbad0bb](https://github.com/mapequation/infomap/commit/fbad0bbff367bf6b63919e6dbb251333ca849278))
* **python:** add tutorial notebooks ([#551](https://github.com/mapequation/infomap/issues/551)) ([5df5574](https://github.com/mapequation/infomap/commit/5df5574d8ac690db6aab79f2e123d7cfcd582f6b))
* **python:** improve dataframe and dependency ergonomics ([6c659f4](https://github.com/mapequation/infomap/commit/6c659f40dbddcb426fdfbbc34f2595a05740791a))
* **R:** add cluster_infomap_multilayer() helper ([#515](https://github.com/mapequation/infomap/issues/515)) ([c9c8f24](https://github.com/mapequation/infomap/commit/c9c8f2410fec27629dc3f0a6d69f90c50106eb78))
* regularized multilayer ([#462](https://github.com/mapequation/infomap/issues/462)) ([130bce1](https://github.com/mapequation/infomap/commit/130bce1c1a775867c9033d1c2f7247507838bfb2))
* **R:** expose R link results ([#567](https://github.com/mapequation/infomap/issues/567)) ([5e10f40](https://github.com/mapequation/infomap/commit/5e10f4075f13a7695784946d250220370b1d03fe))


### Bug Fixes

* **js:** improve js package ([#512](https://github.com/mapequation/infomap/issues/512)) ([010fb9b](https://github.com/mapequation/infomap/commit/010fb9b0d896317fc09193164c618de9ead37d49))
* prevent metadata inner parallel crash ([#593](https://github.com/mapequation/infomap/issues/593)) ([38c3a03](https://github.com/mapequation/infomap/commit/38c3a03ad2bfb23a31d70d123a4df7dedeebdc23))
* **python:** rename phys_id to node_id in graph adapter API ([#545](https://github.com/mapequation/infomap/issues/545)) ([22b901e](https://github.com/mapequation/infomap/commit/22b901e42545ef34661e493c500e97ec2f490242))
* **python:** support PyTorch with macOS OpenMP wheels ([#592](https://github.com/mapequation/infomap/issues/592)) ([e7764b3](https://github.com/mapequation/infomap/commit/e7764b30c1093214754ebf2c1fb8ea4c1aaadb63))
* redirect missing infomap pages ([#546](https://github.com/mapequation/infomap/issues/546)) ([f16d76b](https://github.com/mapequation/infomap/commit/f16d76bf76efe0eae7f427f48c1065eefcd72726))
* Reset num non-trivial modules when reset to one module ([4b33082](https://github.com/mapequation/infomap/commit/4b33082307c9868402e866ef2b480289e26aacd3))
* **R:** improve R igraph integration ([#526](https://github.com/mapequation/infomap/issues/526)) ([8b020ee](https://github.com/mapequation/infomap/commit/8b020ee442eb4aa73fc200115f1a68a8b3bf60d7))
* warm-start .tree input on higher-order networks ([6ad980a](https://github.com/mapequation/infomap/commit/6ad980a06740bcbdfe037db453f7c5fd66045ac1))


### Performance Improvements

* **js:** build worker as single-file wasm ([#571](https://github.com/mapequation/infomap/issues/571)) ([89afaf4](https://github.com/mapequation/infomap/commit/89afaf4d877903f4aa57d3c8750f4d38067d1dc2))
* opt-in -march=native + LTO + inlined SIMD log2 polynomial ([#591](https://github.com/mapequation/infomap/issues/591)) ([9a250b1](https://github.com/mapequation/infomap/commit/9a250b1395df55806a0f538371607ed99b22cd68))
* speed up large network input parsing ([#522](https://github.com/mapequation/infomap/issues/522)) ([34ff6bc](https://github.com/mapequation/infomap/commit/34ff6bc614128d7b1ed0e7cb1eebc59c55f7e8d3))
* speed up NumPy link ingestion ([#523](https://github.com/mapequation/infomap/issues/523)) ([6d4857e](https://github.com/mapequation/infomap/commit/6d4857e59780736140cc22cf4a3099f6ebbcf54d))

## [2.10.1](https://github.com/mapequation/infomap/compare/v2.10.0...v2.10.1) (2026-05-05)


### Bug Fixes

* **python:** handle missing CLI arguments ([#509](https://github.com/mapequation/infomap/issues/509)) ([705871d](https://github.com/mapequation/infomap/commit/705871d5d4abf94b0f314c55eb6ab663934dafb9))

## [2.10.0](https://github.com/mapequation/infomap/compare/v2.9.2...v2.10.0) (2026-05-04)


### Features

* add per-level module counts to json output ([#372](https://github.com/mapequation/infomap/issues/372)) ([dc9b30c](https://github.com/mapequation/infomap/commit/dc9b30cd7278d604e7327ddf6c33056d6a471dd2))
* high-level R cluster_infomap helper ([#489](https://github.com/mapequation/infomap/issues/489)) ([0caea75](https://github.com/mapequation/infomap/commit/0caea755138734ee72d65ae38d107cef9ff9aa90))
* library-safe no-output mode and reduced iostream references ([#428](https://github.com/mapequation/infomap/issues/428)) ([b43b8cc](https://github.com/mapequation/infomap/commit/b43b8cc3c6c39ad1b86d1751e138b1b68a1c1651))
* **r:** add idiomatic R package with SWIG bindings and CI ([#464](https://github.com/mapequation/infomap/issues/464)) ([c4b3103](https://github.com/mapequation/infomap/commit/c4b31034f90a5fba35e4be47cd45512cb166637f))


### Bug Fixes

* avoid expensive vector copies in regularized flow lambdas ([#371](https://github.com/mapequation/infomap/issues/371)) ([23445fc](https://github.com/mapequation/infomap/commit/23445fcdf708f0ad1d0621c753582d63a9d14bb6))
* Check random moves for weakly connected nodes ([#442](https://github.com/mapequation/infomap/issues/442)) ([3d05b8f](https://github.com/mapequation/infomap/commit/3d05b8fc5ea221455cfd0fd49091229dd96b35fb))
* **ci:** enforce low-noise clang-tidy checks ([#485](https://github.com/mapequation/infomap/issues/485)) ([f157c05](https://github.com/mapequation/infomap/commit/f157c05c4cea8bdf2d7b9a92374058f34b3b5189))
* correct regularized multilevel codelength ([#461](https://github.com/mapequation/infomap/issues/461)) ([1fae0f7](https://github.com/mapequation/infomap/commit/1fae0f7a3c25cab90197dc74c0e44256df46fdb6))
* delete collapsed children when resetting InfoNode trees ([#403](https://github.com/mapequation/infomap/issues/403)) ([050a686](https://github.com/mapequation/infomap/commit/050a6869a0b028a5957cc1db296b29241f0e4866))
* guard empty-module access in parallel move path ([#404](https://github.com/mapequation/infomap/issues/404)) ([c445a88](https://github.com/mapequation/infomap/commit/c445a88fe6f34f4e51ef834f1722ce822ad8270a))
* guard multilayer state id shift for zero ([#373](https://github.com/mapequation/infomap/issues/373)) ([499b88a](https://github.com/mapequation/infomap/commit/499b88a2184929740f45e5355b0b94fe67e3fb6e))
* handle regularized no-link networks ([#374](https://github.com/mapequation/infomap/issues/374)) ([f2700d0](https://github.com/mapequation/infomap/commit/f2700d03d806cf5f6593be142a5b2accae1178c7))
* plumbing and lifecycle fixes ([#405](https://github.com/mapequation/infomap/issues/405)) ([ce27af6](https://github.com/mapequation/infomap/commit/ce27af604ac8806284ee84ce9de4389ad89839cd))
* repair R release artifact flow ([#496](https://github.com/mapequation/infomap/issues/496)) ([5fa6ddf](https://github.com/mapequation/infomap/commit/5fa6ddf180073155283d0f0677960b00a0016d59))
* restore stream format after codelength output ([#486](https://github.com/mapequation/infomap/issues/486)) ([c35a629](https://github.com/mapequation/infomap/commit/c35a629dd9366a8ad935669bd4f2f74da72e9ea1))
* speed up bulk link loading ([#493](https://github.com/mapequation/infomap/issues/493)) ([59e13e8](https://github.com/mapequation/infomap/commit/59e13e88f94dbf0a4c79e7f3b7d8f114665da46f))
* speed up bulk multilayer link loading ([#497](https://github.com/mapequation/infomap/issues/497)) ([1ec735f](https://github.com/mapequation/infomap/commit/1ec735f183285b482f7bb1a2cf349695b0974b93))
* speed up multilayer intra/inter link loading ([#499](https://github.com/mapequation/infomap/issues/499)) ([6685aab](https://github.com/mapequation/infomap/commit/6685aab04a1cca6000a0395c1beacd8bb133aebf))
* sync matchable multilayer ids for python input ([#494](https://github.com/mapequation/infomap/issues/494)) ([9ff9af8](https://github.com/mapequation/infomap/commit/9ff9af82f8460409315cd20d0d7395fb15a5128d))
* tighten wrapper edge cases ([4a9d542](https://github.com/mapequation/infomap/commit/4a9d54298629fdc484d8c40d44a9f3d6d8434ffd))
* Use consistent convention on degree of self-links ([342321d](https://github.com/mapequation/infomap/commit/342321d0b25a008bd6ccf5ff5815add75c1e1fa9))


### Performance Improvements

* **ci:** add PR perf regression benchmark check ([#427](https://github.com/mapequation/infomap/issues/427)) ([270e527](https://github.com/mapequation/infomap/commit/270e5274ade5b23e0ed2b429bad3e53fe06c085e))

### [2.9.2](https://github.com/mapequation/infomap/compare/v2.9.1...v2.9.2) (2026-02-25)


### Bug Fixes

* **ci:** avoid llvm libc++ dependency for macOS python ([a79b285](https://github.com/mapequation/infomap/commit/a79b2859769d3158adbc9750de466e85587b6a8a))
* **ci:** remove llvm dependency and use cibuildwheel ([d51fac4](https://github.com/mapequation/infomap/commit/d51fac427b3d1000b1e59baee2afb5c92225c365))

### [2.9.1](https://github.com/mapequation/infomap/compare/v2.9.0...v2.9.1) (2026-02-25)


### Bug Fixes

* **ci:** avoid embedding Homebrew libunwind in macOS builds ([0377ca2](https://github.com/mapequation/infomap/commit/0377ca21cce0f203ee30205ebda3ac0c2deecd65))

## [2.9.0](https://github.com/mapequation/infomap/compare/v2.8.2...v2.9.0) (2026-02-25)


### Features

* Enhance Infomap CLI summary output with more info ([35a3bc9](https://github.com/mapequation/infomap/commit/35a3bc9282964342cbb4a67c3221684857650ad8))

### [2.8.2](https://github.com/mapequation/infomap/compare/v2.8.1...v2.8.2) (2026-02-24)


### Bug Fixes

* Restore correct codelength on worse 2-level higher-order solution ([36f9870](https://github.com/mapequation/infomap/commit/36f987094bd66822e2e2350d53690859e91da21e))
* Use provided state ids on networkx multilayer graph ([33c2978](https://github.com/mapequation/infomap/commit/33c2978d7698bc5f6f841ce2d3609c8dcd738b05))

### [2.8.1](https://github.com/mapequation/infomap/compare/v2.8.0...v2.8.1) (2026-02-11)


### Bug Fixes

* Adjust regularization for memory networks ([629f63c](https://github.com/mapequation/infomap/commit/629f63c671c2f3bce6f003aa70da9c9ef166c7cb))
* Always use network in run(Network& network) ([60a86c7](https://github.com/mapequation/infomap/commit/60a86c76ffd4157542a468410ca251d2811535b9)), closes [#364](https://github.com/mapequation/infomap/issues/364)
* Avoid non-converging flow due to large perturbation ([1a0747a](https://github.com/mapequation/infomap/commit/1a0747a0e8671d2fdb90b0906ad8c4433ad43513))
* **py:** Make storing iterator items work ([b3f5877](https://github.com/mapequation/infomap/commit/b3f5877e6ac83895d859cd85475ada2cef69711e))
* Restore to correct codelength for -2 regularized states ([3cd7d5e](https://github.com/mapequation/infomap/commit/3cd7d5e8bb86728d0a7bf7a037e404951f998da0))

## [2.8.0](https://github.com/mapequation/infomap/compare/v2.7.1...v2.8.0) (2024-06-20)


### Features

* Add state network from NetworkX graph ([#344](https://github.com/mapequation/infomap/issues/344)) ([1467768](https://github.com/mapequation/infomap/commit/1467768d8850860977c05142c0d3d4c3aaf5eea0))


### Bug Fixes

* **py:** Use inter/intra multilayer format by default ([0ed9af3](https://github.com/mapequation/infomap/commit/0ed9af30af19cbede0317f71ef44a5b5193661fc))
* Upgrade github actions dependencies ([ffe0fe2](https://github.com/mapequation/infomap/commit/ffe0fe21f98e70a918fdd45157f960eb770c153d))

### [2.7.1](https://github.com/mapequation/infomap/compare/v2.7.0...v2.7.1) (2023-04-25)


### Bug Fixes

* Allow precomputed flow for state networks ([ab7c5b5](https://github.com/mapequation/infomap/commit/ab7c5b55b294a3e256ed53f903e888efc08f1ae6))

## [2.7.0](https://github.com/mapequation/infomap/compare/v2.6.1...v2.7.0) (2023-04-04)


### Features

* Add flow model "precomputed" ([407dbe9](https://github.com/mapequation/infomap/commit/407dbe9592641bea7a4cac292a7d25df308644ca))


### Bug Fixes

* Do not add links with zero weight ([cc61b61](https://github.com/mapequation/infomap/commit/cc61b61db228e8a0b433d5bc55f0fedc540e1c0d)), closes [#324](https://github.com/mapequation/infomap/issues/324)
* **python:** Typo in assign_to_neighbouring_module ([c644e80](https://github.com/mapequation/infomap/commit/c644e80d1717cc28c6247b470e4f1c6eb2d4a420))

### [2.6.1](https://github.com/mapequation/infomap/compare/v2.6.0...v2.6.1) (2022-10-31)


### Bug Fixes

* Scale variable Markov time logarithmic as default ([#320](https://github.com/mapequation/infomap/issues/320)) ([3f40134](https://github.com/mapequation/infomap/commit/3f40134b0346586b9d051c3a2996a77500ba10d6))
* Set num trials to 1 if no infomap ([be60a09](https://github.com/mapequation/infomap/commit/be60a09c785d8bee9ac885ebc92473494db368c1))

## [2.6.0](https://github.com/mapequation/infomap/compare/v2.5.0...v2.6.0) (2022-08-09)


### Features

* **python:** Add entropy_rate property ([a243dfc](https://github.com/mapequation/infomap/commit/a243dfcdf4629aff85b425d11aa7317b1fc6b80c))
* Variable Markov time ([#315](https://github.com/mapequation/infomap/issues/315)) ([cd7b25b](https://github.com/mapequation/infomap/commit/cd7b25b8aded24f85034ddc0d2d3bbacb881b24c))


### Bug Fixes

* Adjust entropy correction to Miller-Madow ([324c9f7](https://github.com/mapequation/infomap/commit/324c9f757d94b2d045ec77d14b53491ef30aba17))
* Don't write multilevel json output for aggregated higher-order networks ([1f5e7ea](https://github.com/mapequation/infomap/commit/1f5e7eab31b865fd2208cecbd0ed50642b9ca199))
* Fix calc entropy rate for undirected networks ([ccd6b6c](https://github.com/mapequation/infomap/commit/ccd6b6cbdb8b322a5e457355a214801301351d4a))
* **py:** Fix ignored variable_markov_time argument ([eedc777](https://github.com/mapequation/infomap/commit/eedc77705e44255c580d973c9403d1062a6e1712))
* **py:** Fix test for entropy rate ([78772b5](https://github.com/mapequation/infomap/commit/78772b5b81323d65456220e23456210c48fc0871))
* **python:** Fix physical leaf node iterator on state networks ([#312](https://github.com/mapequation/infomap/issues/312)) ([4e2918c](https://github.com/mapequation/infomap/commit/4e2918c131beeda4187012e8c9672e3635f77df4)), closes [#313](https://github.com/mapequation/infomap/issues/313)
* **python:** Only aggregate states into physical nodes when we have a higher-order network ([7e3277c](https://github.com/mapequation/infomap/commit/7e3277c97881057b36756f6328089ed7252234eb))
* **python:** Segfault when accessing physical_nodes ([cc5c95e](https://github.com/mapequation/infomap/commit/cc5c95e302e5093ee168a9952bbb70dc1e5b74ce)), closes [#300](https://github.com/mapequation/infomap/issues/300)

## [2.5.0](https://github.com/mapequation/infomap/compare/v2.4.1...v2.5.0) (2022-06-07)


### Features

* Output per-module codelength in json ([eae6650](https://github.com/mapequation/infomap/commit/eae6650c48dbf90a938d011f1c736794a786d7ef))
* Print all trials using --print-all-trials ([e65bea8](https://github.com/mapequation/infomap/commit/e65bea86c21ebcabafb053e79306049e92429ca1)), closes [#298](https://github.com/mapequation/infomap/issues/298)
* Write node metadata to json ([472b791](https://github.com/mapequation/infomap/commit/472b791742f0f692a0a4b06262b33165245f6f36))


### Bug Fixes

* Constrain numerical arguments to sensible values ([174c99f](https://github.com/mapequation/infomap/commit/174c99fb56c4a50a2e11c37208bcec3e98ba4ab4))
* Don't allow less than 1 trial ([18e97e2](https://github.com/mapequation/infomap/commit/18e97e21d76e7d27520eb2625c281031d72376d3))
* Json multilevel modules for higher-order networks ([d020c7c](https://github.com/mapequation/infomap/commit/d020c7c444d1227cb26aa249f7cae5e7de5ecaa4)), closes [#266](https://github.com/mapequation/infomap/issues/266)
* Only print all trials when running with more than 1 trial ([5f9d8b5](https://github.com/mapequation/infomap/commit/5f9d8b5e56ae348b142404f3f775ad526d396c55))
* **python:** Fix elapsed running time ([1131e84](https://github.com/mapequation/infomap/commit/1131e845243d3053cceae5bdf069569b2856bc4a))
* **python:** Replace MersenneTwister implementation with stdlib ([be3effd](https://github.com/mapequation/infomap/commit/be3effd9813a00892437c806b62cb8ee15387d3d))

### [2.4.1](https://github.com/mapequation/infomap/compare/v2.4.0...v2.4.1) (2022-05-27)


### Bug Fixes

* Json output causes segfault ([78e80c5](https://github.com/mapequation/infomap/commit/78e80c581edd92001818abdf50066b798251c604))

## [2.4.0](https://github.com/mapequation/infomap/compare/v2.3.0...v2.4.0) (2022-05-24)


### Features

* **js:** React hook ([c19a819](https://github.com/mapequation/infomap/commit/c19a81917849e27298d00bc1b7c6bde2d66f46c5))


### Bug Fixes

* **js-parser:** Parse module level from clu files ([bb91066](https://github.com/mapequation/infomap/commit/bb9106625761716dfabbb240ba39702c110f011a))
* **js:** Correctly parse clu-files without header ([04c39ea](https://github.com/mapequation/infomap/commit/04c39ea46b716fb10af987a568d5ab226e6ad69d))
* **python:** Don't allow adding multilayer intra-inter links and ordinary nodes. ([8c3d09c](https://github.com/mapequation/infomap/commit/8c3d09c5c5188c1c94d691beff2c519100b939f9)), closes [#287](https://github.com/mapequation/infomap/issues/287)
* **python:** Improve constructor and run signatures ([6852e14](https://github.com/mapequation/infomap/commit/6852e142343c91e61a9affe9bcff2897375cf70c)), closes [#286](https://github.com/mapequation/infomap/issues/286)
* **python:** no_self_links was always set unless include_self_links=True ([9afe5fa](https://github.com/mapequation/infomap/commit/9afe5fa7afbf3f143dd2b8d293be59f572a14c79))
* **python:** Prevent infinite loop in getMultilevelModules ([1174b66](https://github.com/mapequation/infomap/commit/1174b6658ed5c0bbc2c976223524f5f58e4d6c35)), closes [#284](https://github.com/mapequation/infomap/issues/284)
* Using deprecated option --include-self-links references missing option --no-loops ([1497bf7](https://github.com/mapequation/infomap/commit/1497bf71fe7a6f5dad725742db8c36a49171eb4d))

## [2.3.0](https://github.com/mapequation/infomap/compare/v2.2.0...v2.3.0) (2022-04-13)


### Features

* Matchable multilayer ids ([c9d28b6](https://github.com/mapequation/infomap/commit/c9d28b6e739731043e0dd6b82d0ae9898f686618)), closes [#279](https://github.com/mapequation/infomap/issues/279)


### Bug Fixes

* **js:** Don't call error on worker terminate ([cc57c8c](https://github.com/mapequation/infomap/commit/cc57c8cbafa3ec313426e1356a8140fa6d09c9b5))
* **js:** More robust heuristic to parse output format type ([33bde00](https://github.com/mapequation/infomap/commit/33bde00775c2fd41fb03b7592ae80633f09e8263))
* Match multilayer nodes by node and layer ids when using --cluster-data ([b5f6eb3](https://github.com/mapequation/infomap/commit/b5f6eb38d1740559ae93591e659ff8f2f53b7927))
* **python:** Add no_self_links to api ([b3d903d](https://github.com/mapequation/infomap/commit/b3d903d16e7619edebabe58a9004f40c88ea3614)), closes [#285](https://github.com/mapequation/infomap/issues/285)
* **python:** Add recorded teleportation keyword argument ([839e1e0](https://github.com/mapequation/infomap/commit/839e1e057b2f7181a87d77758ae00c20aa368891)), closes [#270](https://github.com/mapequation/infomap/issues/270)
* **python:** Fix matchable multilayer id option ([8377e07](https://github.com/mapequation/infomap/commit/8377e077832eafba1cb989dcad6e24b7a8f87edf))

## [2.2.0](https://github.com/mapequation/infomap/compare/v2.1.0...v2.2.0) (2022-03-07)


### Features

* Add flow-model, higher-order, and state-level fields to json, tree and clu output ([24125e5](https://github.com/mapequation/infomap/commit/24125e5874cd0599e7274e08a2691855f212186b))


### Bug Fixes

* **js:** More forgiving clu and tree parsing ([4764946](https://github.com/mapequation/infomap/commit/47649466a0ef2a200dc766b1442c7f33a8fec20f))
* Write json output with --no-infomap ([c0cec87](https://github.com/mapequation/infomap/commit/c0cec8715981f53dd53c3134c8f16e5b4d644717)), closes [#268](https://github.com/mapequation/infomap/issues/268)

## [2.1.0](https://github.com/mapequation/infomap/compare/v2.0.2...v2.1.0) (2022-02-11)


### Features

* **js:** Add progress event callback ([0fab95b](https://github.com/mapequation/infomap/commit/0fab95bd59717aaf2f36792f2be5a54223e38fab))


### Bug Fixes

* **js:** Change Typescript types to use mec instead of modularCentrality ([298eed3](https://github.com/mapequation/infomap/commit/298eed32d977758b07af058327775c234340b7b5))
* **js:** Parse node path as string instead of array of number ([51feb73](https://github.com/mapequation/infomap/commit/51feb73254b17857e4feb27197d4bb8c8157db05))
* **js:** Validate parsed results and throw instead of returning null on failure ([5f56b94](https://github.com/mapequation/infomap/commit/5f56b94fe0f956483f61a03ef07e94d8def2205e))

### [2.0.2](https://github.com/mapequation/infomap/compare/v2.0.1...v2.0.2) (2022-01-31)


### Bug Fixes

* Change json key modularCentrality to mec ([78c7a57](https://github.com/mapequation/infomap/commit/78c7a573914e127bda03a2b8001df321e5bffd04))
* **js:** Parse directed field in ftree files ([916f54a](https://github.com/mapequation/infomap/commit/916f54a05fb2ffd86ddf0ba297952e85ccfaa5b8))
* **js:** Pass parseLinks to main parse function and correctly detect multilayer tree files ([0a40ca6](https://github.com/mapequation/infomap/commit/0a40ca6c1606c189f02e691a2fdb74a4494ffbe7))
* Minify json output ([123c2b1](https://github.com/mapequation/infomap/commit/123c2b10f1e6486135346f8cd546ca0e72fb4d2e)), closes [#260](https://github.com/mapequation/infomap/issues/260)

### [2.0.1](https://github.com/mapequation/infomap/compare/v2.0.0...v2.0.1) (2022-01-26)


### Bug Fixes

* Bug in write state network to json ([50f8de2](https://github.com/mapequation/infomap/commit/50f8de2008cf6422693a74279b347d043735200d)), closes [#262](https://github.com/mapequation/infomap/issues/262)
* **js:** Broken parser due to duplicate variable name ([f437e13](https://github.com/mapequation/infomap/commit/f437e138f7b24140732831e63fac8c28e44e44bf))
* Use min mass for dangling nodes when regularized ([f741d07](https://github.com/mapequation/infomap/commit/f741d079b04558102130cbbbd742a0ddc3c1c366))

## [2.0.0](https://github.com/mapequation/infomap/compare/v1.9.0...v2.0.0) (2022-01-13)


### ⚠ BREAKING CHANGES

* Removes --input-format.
* Removes --include-self-links.

### Features

* Entropy bias correction ([#258](https://github.com/mapequation/infomap/issues/258)) ([8ea235c](https://github.com/mapequation/infomap/commit/8ea235cf9159fc1a672a0470798ab7e443590fde))
* Regularized map equation ([#181](https://github.com/mapequation/infomap/issues/181)) ([0673000](https://github.com/mapequation/infomap/commit/06730005329acb4ba781d647e7009d4ff2510ae7)), closes [#256](https://github.com/mapequation/infomap/issues/256)


### Bug Fixes

* Add new feature flags to python and js api ([48245a7](https://github.com/mapequation/infomap/commit/48245a795f87675b62b94b2f8bd8251b71e5f62e))
* Include self links by default ([#255](https://github.com/mapequation/infomap/issues/255)) ([1f68940](https://github.com/mapequation/infomap/commit/1f68940a90633405f696efa93471ca8cbb25f14c))
* **example:** Fix building c++ examples ([0d5c063](https://github.com/mapequation/infomap/commit/0d5c0639cb76b9b275388c1a45873496f675aeea)), closes [#252](https://github.com/mapequation/infomap/issues/252)


* Remove superfluous --input-format flag ([2dd77c4](https://github.com/mapequation/infomap/commit/2dd77c4689c67485454478d739c22c8deb44eda0))

## [1.9.0](https://github.com/mapequation/infomap/compare/v1.8.0...v1.9.0) (2021-11-17)


### Features

* **python:** Add API for intra/inter-layer links ([#245](https://github.com/mapequation/infomap/issues/245)) ([aa31ab2](https://github.com/mapequation/infomap/commit/aa31ab22ff8a706f7b1e5bbf75740d35ef5716bf)), closes [#244](https://github.com/mapequation/infomap/issues/244)


### Bug Fixes

* Incorrect one-level codelength for higher-order input ([5a6d1a1](https://github.com/mapequation/infomap/commit/5a6d1a10657c568f0fddf3afd6729a63e3543081)), closes [#182](https://github.com/mapequation/infomap/issues/182)
* Write "directed", not "1", in cli output notice ([f0a9dc7](https://github.com/mapequation/infomap/commit/f0a9dc722f8e8d5b4ca7e9e30d201f129d210df4))

## [1.8.0](https://github.com/mapequation/infomap/compare/v1.7.3...v1.8.0) (2021-11-05)


### Features

* **js:** Add clu and tree javascript parser ([f0c738c](https://github.com/mapequation/infomap/commit/f0c738c2ebbd4d1f43d14b75f82767b30dbfb02f))
* Add modular centrality score ([31cdd7f](https://github.com/mapequation/infomap/commit/31cdd7fa7a12add63f5b8818e503fe81b3f48555))

### [1.7.3](https://github.com/mapequation/infomap/compare/v1.7.2...v1.7.3) (2021-10-26)


### Bug Fixes

* **js:** Don't run error callback on finish ([13a21f0](https://github.com/mapequation/infomap/commit/13a21f00f445e8a378ca287e080085b47df4653f))

### [1.7.2](https://github.com/mapequation/infomap/compare/v1.7.1...v1.7.2) (2021-10-26)


### Bug Fixes

* **js:** Run error callback on terminate ([e83e897](https://github.com/mapequation/infomap/commit/e83e8970656e654aee353705a85bd7f97aae3f71))

### [1.7.1](https://github.com/mapequation/infomap/compare/v1.7.0...v1.7.1) (2021-10-14)

## [1.7.0](https://github.com/mapequation/infomap/compare/v1.6.0...v1.7.0) (2021-10-04)


### Features

* **python:** Add multilevel_modules property ([0d4cc37](https://github.com/mapequation/infomap/commit/0d4cc375cebe8477ea2e0073f9e7056411c3091e))
* **python:** Add num_levels property ([abd4f7f](https://github.com/mapequation/infomap/commit/abd4f7f8cc272cc20e4996b03a10dd2411a46260))
* **python:** Pass dict to add_nodes ([e30870f](https://github.com/mapequation/infomap/commit/e30870f28366676e105b189980a2c5eb921b9481))
* **python:** Pass dict to add_state_nodes ([5cd9ba2](https://github.com/mapequation/infomap/commit/5cd9ba25db758d2cb1a928c32adfdea21dda87d0))
* **python:** Pass dict to set_names ([0ed79e8](https://github.com/mapequation/infomap/commit/0ed79e8b08ab1ae410a3fdbb4dd59ddb2ecf149a))
* Add directed field to json output ([7db19f2](https://github.com/mapequation/infomap/commit/7db19f216b3d7f825a7eb90c89e0a0696c3a3e95))
* Write json multilevel modules and module information ([e6796c8](https://github.com/mapequation/infomap/commit/e6796c8d91499c1287278ab818c7e62d7426c303))


### Bug Fixes

* **python:** Adding a networkx DiGraph should set the directed flag ([a60a404](https://github.com/mapequation/infomap/commit/a60a404eac88d04a3bb6beb1b130452b28a99d83))
* **python:** Using directed=False should use undirected flow ([be0f6e2](https://github.com/mapequation/infomap/commit/be0f6e2f9ffc80ee58305709ebc6b801187e21bb))
* Metadata codelength works after multiple runs ([ec00ccd](https://github.com/mapequation/infomap/commit/ec00ccd7d14bdff54e6757b4cd1fd84e93dd4e58)), closes [#167](https://github.com/mapequation/infomap/issues/167)
* Module ids wrong for uneven depth and chosen level > 1 ([c3a0c90](https://github.com/mapequation/infomap/commit/c3a0c9025ae82a84f05e929f105b88d1d28f8be1)), closes [#221](https://github.com/mapequation/infomap/issues/221)

## [1.6.0](https://github.com/mapequation/infomap/compare/v1.5.1...v1.6.0) (2021-07-08)


### Features

* **python:** Add get_dataframe ([13066b3](https://github.com/mapequation/infomap/commit/13066b3300c921dcb18b46be2a633153ecf0ffa8))
* **python:** Add write method ([fdb3ce1](https://github.com/mapequation/infomap/commit/fdb3ce13a96c77b46b064fcda5fdcaf0f0a3c753))
* **python:** Add write_state_network and write_pajek ([da715a9](https://github.com/mapequation/infomap/commit/da715a9ccfc27b6dd2a079bd9f4e3ef6501a95a1))


### Bug Fixes

* Intra-module links missing from ftree output ([b347e24](https://github.com/mapequation/infomap/commit/b347e2491f343f2a541e6a3e4b7ac8837d0ae507))
* **js:** Add type to files parameter ([269b426](https://github.com/mapequation/infomap/commit/269b426326e7eca02b53dcbddf3ae0925a4b5a23))
* **js:** Output arguments should not be required to be an array ([a292318](https://github.com/mapequation/infomap/commit/a29231853e4d900e5f99dee962b1f44a20fc4e93))
* **js:** Worker should accept extra files as objects ([524a0e7](https://github.com/mapequation/infomap/commit/524a0e7e80c2bef897dab85cd60473a3e06408c9))
* **python:** get_multilevel_modules should return a dict ([f050fb5](https://github.com/mapequation/infomap/commit/f050fb568df4fb678e6c4689bef85cf18a6d93f2))

### [1.5.1](https://github.com/mapequation/infomap/compare/v1.5.0...v1.5.1) (2021-06-23)


### Bug Fixes

* **js:** Add missing flow network file output ([6b8ddb8](https://github.com/mapequation/infomap/commit/6b8ddb820bc48eaed27a4e66d2810151b65b8bb9))
* **js:** Handle json parse exceptions in worker ([a8a127b](https://github.com/mapequation/infomap/commit/a8a127b02e81b1bbd2a919edbc7952724b2e8682))
* **js:** Pass arguments as object ([13e71a0](https://github.com/mapequation/infomap/commit/13e71a0b1a7465e5f59bb3d05ef1bbdef7b5f65f))
* **js:** Worker should accept network as object ([d7184b8](https://github.com/mapequation/infomap/commit/d7184b840e7aae3b7d59b9b8bb2fa432d8d4c616))
* Avoid nan values for relative codelength savings ([e6a429e](https://github.com/mapequation/infomap/commit/e6a429e6bd463fc405161f6b4e981439979fc5c3))

## [1.5.0](https://github.com/mapequation/infomap/compare/v1.4.4...v1.5.0) (2021-06-22)


### Features

* **js:** Add Typescript types to JS worker ([f2fecf4](https://github.com/mapequation/infomap/commit/f2fecf4898dd0200709def0da11bea1883e70eaa))
* **python:** Add get_links, links and flow_links ([a4c2611](https://github.com/mapequation/infomap/commit/a4c26112821abc05185442b1eb27fd1bf83fdbc9))
* Write tree to CSV file ([5d0d36a](https://github.com/mapequation/infomap/commit/5d0d36a58413c0755f97d93dd00d8f6db7b2b785))

### [1.4.4](https://github.com/mapequation/infomap/compare/v1.4.3...v1.4.4) (2021-06-14)


### Bug Fixes

* **python:** Fix OpenMP detection ([27f9070](https://github.com/mapequation/infomap/commit/27f9070d4676aee859f14bbf0ba2e1de6a417636))

### [1.4.3](https://github.com/mapequation/infomap/compare/v1.4.2...v1.4.3) (2021-06-14)

### [1.4.2](https://github.com/mapequation/infomap/compare/v1.4.1...v1.4.2) (2021-06-14)


### Bug Fixes

* **build:** Fix building Python package with OpenMP if available ([cfaade5](https://github.com/mapequation/infomap/commit/cfaade5bb699980954fc6d618ef1eb211bb2a63e))

### [1.4.1](https://github.com/mapequation/infomap/compare/v1.4.0...v1.4.1) (2021-06-10)


### Bug Fixes

* **js:** Add newick and json to output from JS worker ([549ee84](https://github.com/mapequation/infomap/commit/549ee84858860680d2b9ed93e2d79a419c24e7d1))
* **python:** Add missing write_newick and write_json methods ([62c2736](https://github.com/mapequation/infomap/commit/62c2736dfb048de432093313e19b3d67869d3138))
* Change Newick output extention to .nwk ([f0e2e8e](https://github.com/mapequation/infomap/commit/f0e2e8ef8b6f5da6985c548b2f2b00521177cad8))

## [1.4.0](https://github.com/mapequation/infomap/compare/v1.3.0...v1.4.0) (2021-06-10)


### Features

* Support printing JSON tree ([22116d6](https://github.com/mapequation/infomap/commit/22116d6a9077909c2e5eb2160feea913022752e8))
* **python:** Accept named arguments ([5dabf4a](https://github.com/mapequation/infomap/commit/5dabf4abbaa90512d5a1ffd11c8986f8623ccb13))
* **python:** Add 'add_networkx_graph' method to API ([4067d40](https://github.com/mapequation/infomap/commit/4067d40268c4b2726652b5ef47358ca049c58edd))
* **python:** Add effective number of modules ([0f9a516](https://github.com/mapequation/infomap/commit/0f9a5169cacde5c9106bb6cf7dfa3b726a1c28d5))
* **python:** Add shorthand for accessing number of nodes and links ([8808045](https://github.com/mapequation/infomap/commit/88080454e054c51516ee7047975baf480ce1bd42))
* Add 'flow' to output options for node/edge flow ([d74a773](https://github.com/mapequation/infomap/commit/d74a773dd33102b85ff444158c958a8048c8cb02))


### Bug Fixes

* **python:** Also add nodes in networkx example ([3a88878](https://github.com/mapequation/infomap/commit/3a888789cc229521cffdf6da62fd0c239a5607eb))
* **python:** Fix effective_num_modules ([f41827f](https://github.com/mapequation/infomap/commit/f41827fde6f30e914e73d8a141992c4363f14adc))
* **R:** Expose base class methods to avoid c stack usage error ([47bdec0](https://github.com/mapequation/infomap/commit/47bdec0ab9a3d0e80cd7a77a7629ad9d9b400183))
* **R:** Fix swig build by hiding python specifics ([6b8a67e](https://github.com/mapequation/infomap/commit/6b8a67e6f09a02daad8e85c8b9fcec0f632526e3))
* **R:** Replace enum class with struct for R ([73c702f](https://github.com/mapequation/infomap/commit/73c702fd23e7a02ae8ccc3630f5713181cb842a9))
* **R:** Update R example and build to Infomap v1 ([17e1cc0](https://github.com/mapequation/infomap/commit/17e1cc00bd789c8798bd0633a39285a4160854a4))
* **R:** Update swig version in docker build ([74c4e86](https://github.com/mapequation/infomap/commit/74c4e86cfdd395ec1b335fc34dd5e0b34d7f6c1e))

## [1.3.0](https://github.com/mapequation/infomap/compare/v1.2.1...v1.3.0) (2020-12-03)


### Features

* Add --hide-bipartite-nodes ([#156](https://github.com/mapequation/infomap/issues/156)) ([f5e673c](https://github.com/mapequation/infomap/commit/f5e673c64efaf5ae825ee6b303e78389b8d594f9))
* New optional flow model for bipartite input ([91f35fe](https://github.com/mapequation/infomap/commit/91f35fef9b1246b87cde46d8e36ad7a992291a28))
* Support Newick tree format in output ([9749a05](https://github.com/mapequation/infomap/commit/9749a0535b9db47826c198b6f98b8fe2510eadc4))


### Bug Fixes

* Continue searching from input tree ([2199921](https://github.com/mapequation/infomap/commit/21999211ed822a8e46a8f1cd158185ce79b3075e))
* Fine-tune bottom modules in input tree with -F ([c187718](https://github.com/mapequation/infomap/commit/c187718e49618e2dac6c060233c844ff9a40893f))
* Implement missing multilayer relax by JSD ([95141bf](https://github.com/mapequation/infomap/commit/95141bf89452053a5f8f7bb2afbfc4048f066ee3)), closes [#154](https://github.com/mapequation/infomap/issues/154)
* Use correct objective in coarse tune for memory and multilevel networks ([97db558](https://github.com/mapequation/infomap/commit/97db558f27a81994a09aa6834bff5d8810a93130)), closes [#174](https://github.com/mapequation/infomap/issues/174)

### [1.2.1](https://github.com/mapequation/infomap/compare/v1.2.0...v1.2.1) (2020-11-10)


### Bug Fixes

* --clu-level was not respected in command line usage ([b82a0b1](https://github.com/mapequation/infomap/commit/b82a0b1a0582583b4552887650b0a6b92aba14fc)), closes [#153](https://github.com/mapequation/infomap/issues/153)
* Allow ftree cluster data ([bfe3601](https://github.com/mapequation/infomap/commit/bfe3601a50675cf353379efdb940b184773fb2b2))
* Apply weight-threshold also to multilayer nodes ([db2d781](https://github.com/mapequation/infomap/commit/db2d781c5257932ad5a4e5fe1976498b01985a39))
* Remove ClusterReader/BipartiteClusterReader ([8e08309](https://github.com/mapequation/infomap/commit/8e0830915f47bd4460a1b1b4f3794d60919a429a)), closes [#162](https://github.com/mapequation/infomap/issues/162)
* **windows:** Include algorithm header ([4f9ef88](https://github.com/mapequation/infomap/commit/4f9ef88409012ff00457291fc0ad8d0f33063c59)), closes [#150](https://github.com/mapequation/infomap/issues/150)

## [1.2.0](https://github.com/mapequation/infomap/compare/v1.1.4...v1.2.0) (2020-09-30)


### Features

* Add option to --use-node-weights-as-flow ([0d75174](https://github.com/mapequation/infomap/commit/0d751745ba565e06f93dfad6feb79ac9c6794e1e))
* Show bipartite start id in bipartite output ([f6e9233](https://github.com/mapequation/infomap/commit/f6e9233932f39f2dbe72b842fe2ddb259b725e08))


### Bug Fixes

* Fix flow calculator for bipartite networks ([b725b27](https://github.com/mapequation/infomap/commit/b725b27563e84092438839606aba294d7b993de5))
* **python:** Fix bipartite_start_id getter ([d326298](https://github.com/mapequation/infomap/commit/d326298c22570ded7002a8ee9cc361a448d8e4c5))

### [1.1.4](https://github.com/mapequation/infomap/compare/v1.1.3...v1.1.4) (2020-09-13)


### Bug Fixes

* Clarify that the algorithm searches for multi-level solutions by default ([47be4de](https://github.com/mapequation/infomap/commit/47be4defa349e3be99851105aff290cd488b9282))
* **python:** Fix color indices in networkx example ([dcf5888](https://github.com/mapequation/infomap/commit/dcf588800faf7f5d1f9be13d0bcc5528a2c2cf18))

### [1.1.3](https://github.com/mapequation/infomap/compare/v1.1.2...v1.1.3) (2020-05-09)


### Bug Fixes

* **python:** Correct codelength terms after N > 1 ([146cee6](https://github.com/mapequation/infomap/commit/146cee6246e55fb9c4a711c1278bdc251b54fced))
* **python:** Define module_codelength as L - L_index ([fa6eb94](https://github.com/mapequation/infomap/commit/fa6eb946acb22d808cd286bcfad6d76d3f2d4293))
* **python:** Don't create empty node names if they didn't already exist ([#126](https://github.com/mapequation/infomap/issues/126)) ([4d1cd56](https://github.com/mapequation/infomap/commit/4d1cd565e356f5c4ac4e8ce1620ae128a0f9ad4c))
* **python:** Expose num_non_trivial_top_modules ([6b91184](https://github.com/mapequation/infomap/commit/6b911842693f46546fdc89beb145394ed74dacdf))

### [1.1.2](https://github.com/mapequation/infomap/compare/v1.1.1...v1.1.2) (2020-04-08)


### Bug Fixes

* **python:** Expose node names with get_name and get_names ([#125](https://github.com/mapequation/infomap/issues/125)) ([b8cb409](https://github.com/mapequation/infomap/commit/b8cb409eec171d63f60634ce3a19cc01bc3a6eef)), closes [#52](https://github.com/mapequation/infomap/issues/52)

### [1.1.1](https://github.com/mapequation/infomap/compare/v1.1.0...v1.1.1) (2020-04-08)


### Bug Fixes

* Remove implied link direction from --skip-adjust-bipartite-flow ([05c3eba](https://github.com/mapequation/infomap/commit/05c3eba891521e6833292802c9c9671dee1303f7))

## [1.1.0](https://github.com/mapequation/infomap/compare/v1.0.11...v1.1.0) (2020-03-31)


### Features

* Show num levels and modules in file output ([0b70cd8](https://github.com/mapequation/infomap/commit/0b70cd82030693faaf24a318d45b7e929dc61c77))
* **python:** Expose codelengths for all trials ([eab7ae8](https://github.com/mapequation/infomap/commit/eab7ae861b2d93a9aea640994b53a80f4a52030c))


### Bug Fixes

* Don't use physical names in _states_as_physical.net ([5889fb1](https://github.com/mapequation/infomap/commit/5889fb17b13a38b1ce7a3b5ae714810bba1406c2))

### [1.0.11](https://github.com/mapequation/infomap/compare/v1.0.10...v1.0.11) (2020-03-31)


### Bug Fixes

* Handle zero weights in intra-layer links ([ddc5a3d](https://github.com/mapequation/infomap/commit/ddc5a3d827013cc006bdfa4b3518c32aef2ec722))

### [1.0.10](https://github.com/mapequation/infomap/compare/v1.0.9...v1.0.10) (2020-03-17)


### Bug Fixes

* Handle unassigned nodes after input tree ([d337535](https://github.com/mapequation/infomap/commit/d33753500939912035e30db4b4dfaf38beeb3eb1)), closes [#119](https://github.com/mapequation/infomap/issues/119)

### [1.0.9](https://github.com/mapequation/infomap/compare/v1.0.8...v1.0.9) (2020-03-14)


### Bug Fixes

* **windows:** compilation error on std::min ([b6c1a41](https://github.com/mapequation/infomap/commit/b6c1a419ad7f732520723a5df621eaed4bb5d2da))

### [1.0.8](https://github.com/mapequation/infomap/compare/v1.0.7...v1.0.8) (2020-03-12)


### Bug Fixes

* Fix reconstruct physically merged state nodes ([dc91e1a](https://github.com/mapequation/infomap/commit/dc91e1ad93fe150c58994c9dd2ab3aebefd84ef8)), closes [#118](https://github.com/mapequation/infomap/issues/118)
* Remove debug output ([#117](https://github.com/mapequation/infomap/issues/117)) ([60e7ab3](https://github.com/mapequation/infomap/commit/60e7ab346f50d3cedff06a6b7a12ef106b296f5a))

### [1.0.7](https://github.com/mapequation/infomap/compare/v1.0.6...v1.0.7) (2020-03-09)


### Bug Fixes

* Add header in network and states output ([c415a4b](https://github.com/mapequation/infomap/commit/c415a4bf05625eaa2330e6e9e3c9b1e2797895c5))
* Use *Edges/*Arcs instead of *Links in pajek output ([ff3a98e](https://github.com/mapequation/infomap/commit/ff3a98e18c119a64b8324018920452b6611b77d2))
* Use node_id instead of id in clu output ([39cd4e4](https://github.com/mapequation/infomap/commit/39cd4e4d866ee03c1d701946225a2bd76a0a9790))
* **js:** Fix support for all file io in Infomap.js ([ea9d899](https://github.com/mapequation/infomap/commit/ea9d899bdebdd361f0ff90e673471f92bc46cfaa))

### [1.0.6](https://github.com/mapequation/infomap/compare/v1.0.5...v1.0.6) (2020-03-03)


### Bug Fixes

* **python:** Enable numpy.int64 in link weights ([8d91206](https://github.com/mapequation/infomap/commit/8d9120681f932bd0cfad37cc4740f719f2acb358)), closes [#107](https://github.com/mapequation/infomap/issues/107)
* **python:** Print tree by default with python cli ([1565cab](https://github.com/mapequation/infomap/commit/1565cab1f3afec8c555180dd620379557709d3d0)), closes [#106](https://github.com/mapequation/infomap/issues/106)

### [1.0.5](https://github.com/mapequation/infomap/compare/v1.0.4...v1.0.5) (2020-03-02)


### Bug Fixes

* Common parameters should not be advanced ([#101](https://github.com/mapequation/infomap/issues/101)) ([2907c86](https://github.com/mapequation/infomap/commit/2907c8605313d60fc7c74e36d7a841b2f96c7b1d)), closes [#100](https://github.com/mapequation/infomap/issues/100)
* consistently use 1-based indexing for paths and 0 for indexes ([f283818](https://github.com/mapequation/infomap/commit/f2838189771cfc118ee20152d96694b438168ca8)), closes [#103](https://github.com/mapequation/infomap/issues/103)
* Fix ftree links since remapping path from 1 ([f447b48](https://github.com/mapequation/infomap/commit/f447b4872cb29b651747c08cd919e837353b4354)), closes [#102](https://github.com/mapequation/infomap/issues/102)

### [1.0.4](https://github.com/mapequation/infomap/compare/v1.0.3...v1.0.4) (2020-02-28)


### Bug Fixes

* **js:** Revert attempted worker blob optimization ([c521373](https://github.com/mapequation/infomap/commit/c521373fadaf741a34792ea27cd2efba6813cff9))

### [1.0.3](https://github.com/mapequation/infomap/compare/v1.0.2...v1.0.3) (2020-02-28)


### Bug Fixes

* **js:** Handle Infomap exceptions in js ([7a641f9](https://github.com/mapequation/infomap/commit/7a641f94ddae3df99c2065e77e3a1bc78922e174)), closes [#99](https://github.com/mapequation/infomap/issues/99)
* **python:** Start module id from 1 in get_[multilevel_]modules ([9419798](https://github.com/mapequation/infomap/commit/94197982597df86ae315dd9520ae24c27f67c552))

### [1.0.2](https://github.com/mapequation/infomap/compare/v1.0.1...v1.0.2) (2020-02-28)


### Bug Fixes

* **windows:** Fix compilation error on std::min ([3b000dc](https://github.com/mapequation/infomap/commit/3b000dcea45875e222d69b63ae0c289bcc6efcdc)), closes [#97](https://github.com/mapequation/infomap/issues/97)

### [1.0.1](https://github.com/mapequation/infomap/compare/v1.0.0...v1.0.1) (2020-02-27)


### Bug Fixes

* **python:** Fix missing package_meta on pip install ([dd24b1d](https://github.com/mapequation/infomap/commit/dd24b1d8fa7aa0c0b276dd611c57ef8a110002b8)), closes [#95](https://github.com/mapequation/infomap/issues/95)

## 1.0.0 (2020-02-26)


### ⚠ BREAKING CHANGES

* **python:** Drop support for python 2
* **python:** Rename physicalId to node_id.
Remove initial partition as first argument to run, use initial_partition argument.
Start InfomapIterator.path indexing from one.
* Output header format has changed
* Ftree output format has changed to include enter flow
* Clu output now contains top modules instead of leaf modules
* Tree output is sorted on flow
* Clu module ids starts from 1 instead of 0
* Output contains name of the physical node instead of state id
* Full multilayer format require the *multilayer heading
* Remove undirdir and outdirdir, use --flow-model. Rename min-improment to --core-loop-codelength-thresh. Remove random-loop-limit. Rename tune-iteration-threshold to --tune-iteration-relative-threshold. Rename skip-replace-to-one-module to --prefer-modular-solution.
* Removed --print-state-network, use -o states
* Renamed --set-unidentified-nodes-to-closest-module to
--assing-to-neighbouring-module
* No support for *path input

### Features

* **python:** Add meta info to infomap package ([a2caaf4](https://github.com/mapequation/infomap/commit/a2caaf4ff7f368c237c2752207b097028bacb900)), closes [#63](https://github.com/mapequation/infomap/issues/63)
* Add enter flow to ftree output ([bd3255e](https://github.com/mapequation/infomap/commit/bd3255e61977ce8f1d9e0babb95ec8158710e3a8)), closes [#82](https://github.com/mapequation/infomap/issues/82)
* Show entropy rate in the beginning ([f61692c](https://github.com/mapequation/infomap/commit/f61692c60c681d532f7a45b980f5041199b088b5))
* **python:** Improve Python API ([#87](https://github.com/mapequation/infomap/issues/87)) ([c39cd9f](https://github.com/mapequation/infomap/commit/c39cd9f2a310a10a30e0de83dab95902e8c6aa91))
* Add -o/--output option for comma-separated formats ([a255a18](https://github.com/mapequation/infomap/commit/a255a181f109b51eed3e1cbb82bb5f73f1894dd0))
* Add meta data in output file header ([66ccc64](https://github.com/mapequation/infomap/commit/66ccc64fec74a47a92b053642d7ad5fb63b74df2))
* Add option to print parameters in json ([3a2509d](https://github.com/mapequation/infomap/commit/3a2509d28dec022d5bdd2c8b8a4a5fd87448edab))
* Allow multilayer formats without specifying -i. ([08e09f1](https://github.com/mapequation/infomap/commit/08e09f136321dcf917d0d131d57041d32c923e64))
* Allow one-sided multilayer relax limit ([a116b83](https://github.com/mapequation/infomap/commit/a116b83bcf1240a17aca12a576fe634fd3db91dd)), closes [#68](https://github.com/mapequation/infomap/issues/68)
* Begin module id from 1 instead of 0 in clu output ([2bbea5d](https://github.com/mapequation/infomap/commit/2bbea5d537ef0e68ac167d1f84acbf0888d22fb8))
* Create npm package with Infomap worker, changelog and parameters ([44dae36](https://github.com/mapequation/infomap/commit/44dae36d65e9dccd2462db330298887318bc2463))
* Output name of physical node instead of state id ([dda3277](https://github.com/mapequation/infomap/commit/dda3277a2f97152a5b5011c94e440f9bb5ee9b9b))
* Remove --skip-complete-dangling-memory-nodes ([6909f21](https://github.com/mapequation/infomap/commit/6909f21a3ebc6eb84c5bc10f6f43c1839020ba41))
* Remove support for *path input ([e7be175](https://github.com/mapequation/infomap/commit/e7be175378838b294d64390bd6f59cdc6b8a42f1))
* Rename --set-unidentified-nodes-to-closest-module ([16fdc15](https://github.com/mapequation/infomap/commit/16fdc155d2d1fefbb22af1305f7ae7efcd1f06f4))
* Simplify command line interface ([f537132](https://github.com/mapequation/infomap/commit/f5371328e63d761ccaf6ee1cdce543ced80fe25c))
* Sort tree on flow ([6e27858](https://github.com/mapequation/infomap/commit/6e278584c45367145f57ce6323f6a8a9c2d64ffe)), closes [#71](https://github.com/mapequation/infomap/issues/71)
* Write top modules to .clu, not bottom level ([1e16a3c](https://github.com/mapequation/infomap/commit/1e16a3ccdf15ee6155a22d8d0cd4bc6ebfdeb94f))


### Bug Fixes

* **js:** Add missing this in error handler ([7345cdf](https://github.com/mapequation/infomap/commit/7345cdff8aa2b362df9d6522960fb992f5634f6e))
