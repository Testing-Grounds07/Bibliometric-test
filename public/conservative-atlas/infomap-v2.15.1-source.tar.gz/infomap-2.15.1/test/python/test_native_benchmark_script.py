from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

pytestmark = pytest.mark.fast


def _find_repo_root(start: Path) -> Path:
    target = Path("scripts") / "benchmarks" / "run_native_benchmarks.py"
    for candidate in (start, *start.parents):
        if (candidate / target).exists():
            return candidate
    raise FileNotFoundError(
        f"Could not locate repository root containing {target!s} from {start!s}"
    )


def _load_benchmark_module():
    repo_root = _find_repo_root(Path(__file__).resolve())
    module_path = repo_root / "scripts" / "benchmarks" / "run_native_benchmarks.py"
    spec = importlib.util.spec_from_file_location("run_native_benchmarks", module_path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_benchmark_case_tolerates_missing_rebuild_metrics(monkeypatch, tmp_path: Path):
    benchmark_module = _load_benchmark_module()
    payload = {
        "name": "toy",
        "path": str(tmp_path / "toy.net"),
        "flags": "--silent --no-file-output --num-trials 1 --seed 123",
        "iterations": 1,
        "total_sec": 0.3,
        "read_input_sec": 0.1,
        "run_sec": 0.2,
        "peak_rss_bytes": 4096,
        "node_size_bytes": 32,
        "edge_size_bytes": 16,
        "num_nodes": 5,
        "num_links": 4,
        "num_top_modules": 2,
        "num_levels": 1,
        "codelength": 1.5,
        "higher_order_input": False,
        "directed_input": False,
        "runs": [
            {
                "iteration": 1,
                "read_input_sec": 0.0,
                "run_sec": 0.2,
                "total_sec": 0.2,
                "peak_rss_bytes": 4096,
                "num_top_modules": 2,
                "num_levels": 1,
                "codelength": 1.5,
            }
        ],
    }

    def fake_run(*args, **kwargs):
        return benchmark_module.subprocess.CompletedProcess(
            args[0], 0, stdout=json.dumps(payload), stderr=""
        )

    monkeypatch.setattr(benchmark_module.subprocess, "run", fake_run)

    result = benchmark_module.benchmark_case(
        binary=tmp_path / "infomap_native_benchmark",
        name="toy",
        network_path=tmp_path / "toy.net",
        repeats=1,
        warmup_runs=0,
        iterations=1,
        flags="--silent",
    )

    assert result["rebuild"]["mean_total_sec"] == 0.0
    assert result["rebuild"]["median_total_calls"] == 0
    assert result["rebuild"]["module_size_buckets"] == {}


def test_benchmark_case_collects_dynamic_rebuild_bucket_labels(
    monkeypatch, tmp_path: Path
):
    benchmark_module = _load_benchmark_module()
    payload = {
        "name": "toy",
        "path": str(tmp_path / "toy.net"),
        "flags": "--silent --no-file-output --num-trials 1 --seed 123",
        "iterations": 1,
        "total_sec": 0.5,
        "read_input_sec": 0.1,
        "run_sec": 0.4,
        "peak_rss_bytes": 8192,
        "node_size_bytes": 32,
        "edge_size_bytes": 16,
        "num_nodes": 8,
        "num_links": 12,
        "num_top_modules": 3,
        "num_levels": 2,
        "codelength": 2.5,
        "higher_order_input": False,
        "directed_input": True,
        "runs": [
            {
                "iteration": 1,
                "read_input_sec": 0.0,
                "run_sec": 0.4,
                "total_sec": 0.4,
                "peak_rss_bytes": 8192,
                "num_top_modules": 3,
                "num_levels": 2,
                "codelength": 2.5,
                "rebuild": {
                    "total_sec": 0.05,
                    "network_sec": 0.01,
                    "module_sec": 0.04,
                    "total_calls": 7,
                    "network_calls": 2,
                    "module_calls": 5,
                    "module_size_buckets": {
                        "33-64": {
                            "calls": 2,
                            "sec": 0.03,
                            "prep_sec": 0.01,
                            "index_sec": 0.005,
                            "reserve_sec": 0.004,
                            "clone_sec": 0.006,
                            "edge_clone_sec": 0.005,
                        }
                    },
                },
            }
        ],
    }

    def fake_run(*args, **kwargs):
        return benchmark_module.subprocess.CompletedProcess(
            args[0], 0, stdout=json.dumps(payload), stderr=""
        )

    monkeypatch.setattr(benchmark_module.subprocess, "run", fake_run)

    result = benchmark_module.benchmark_case(
        binary=tmp_path / "infomap_native_benchmark",
        name="toy",
        network_path=tmp_path / "toy.net",
        repeats=1,
        warmup_runs=0,
        iterations=1,
        flags="--silent",
    )

    assert result["rebuild"]["mean_total_sec"] == pytest.approx(0.05)
    assert result["rebuild"]["module_size_buckets"]["33-64"][
        "mean_sec"
    ] == pytest.approx(0.03)


def test_benchmark_case_discards_warmup_samples(monkeypatch, tmp_path: Path):
    benchmark_module = _load_benchmark_module()

    def payload(run_sec: float) -> dict[str, object]:
        return {
            "name": "toy",
            "path": str(tmp_path / "toy.net"),
            "flags": "--silent --no-file-output --num-trials 1 --seed 123",
            "iterations": 1,
            "total_sec": run_sec + 0.1,
            "read_input_sec": 0.1,
            "run_sec": run_sec,
            "peak_rss_bytes": 4096,
            "node_size_bytes": 32,
            "edge_size_bytes": 16,
            "num_nodes": 5,
            "num_links": 4,
            "num_top_modules": 2,
            "num_levels": 1,
            "codelength": 1.5,
            "higher_order_input": False,
            "directed_input": False,
            "runs": [
                {
                    "iteration": 1,
                    "read_input_sec": 0.0,
                    "run_sec": run_sec,
                    "total_sec": run_sec,
                    "peak_rss_bytes": 4096,
                    "num_top_modules": 2,
                    "num_levels": 1,
                    "codelength": 1.5,
                }
            ],
        }

    payloads = [payload(99.0), payload(1.0), payload(3.0)]

    def fake_run(*args, **kwargs):
        return benchmark_module.subprocess.CompletedProcess(
            args[0], 0, stdout=json.dumps(payloads.pop(0)), stderr=""
        )

    monkeypatch.setattr(benchmark_module.subprocess, "run", fake_run)

    result = benchmark_module.benchmark_case(
        binary=tmp_path / "infomap_native_benchmark",
        name="toy",
        network_path=tmp_path / "toy.net",
        repeats=2,
        warmup_runs=1,
        iterations=1,
        flags="--silent",
    )

    assert payloads == []
    assert result["warmup_runs"] == 1
    assert len(result["samples"]) == 2
    assert [sample["run_sec"] for sample in result["samples"]] == [1.0, 3.0]
    assert result["median_run_sec"] == pytest.approx(2.0)
    assert [sample["repeat"] for sample in result["run_samples"]] == [1, 2]


def _minimal_payload(run_sec: float) -> dict[str, object]:
    return {
        "name": "toy",
        "path": "toy.net",
        "flags": "--silent",
        "iterations": 1,
        "total_sec": run_sec + 0.1,
        "read_input_sec": 0.1,
        "run_sec": run_sec,
        "peak_rss_bytes": 4096,
        "node_size_bytes": 32,
        "edge_size_bytes": 16,
        "num_nodes": 5,
        "num_links": 4,
        "num_top_modules": 2,
        "num_levels": 1,
        "codelength": 1.5,
        "higher_order_input": False,
        "directed_input": False,
        "runs": [
            {
                "iteration": 1,
                "read_input_sec": 0.0,
                "run_sec": run_sec,
                "total_sec": run_sec,
                "peak_rss_bytes": 4096,
                "num_top_modules": 2,
                "num_levels": 1,
                "codelength": 1.5,
            }
        ],
    }


def test_benchmark_case_pair_interleaves_and_rotates_the_lead(
    monkeypatch, tmp_path: Path
):
    """Both binaries are measured inside each repeat, taking turns to go first.

    This is the whole point of the pair driver: two sequential blocks read whatever
    the machine was doing during each block, which is enough to invent a verdict on a
    shared runner. Alternating puts both binaries in the same machine state, and
    rotating the lead keeps the first position -- which pays the cold-cache cost --
    from favouring either binary.
    """
    benchmark_module = _load_benchmark_module()
    invoked: list[str] = []

    def fake_run(command, *args, **kwargs):
        invoked.append(Path(command[0]).name)
        return benchmark_module.subprocess.CompletedProcess(
            command, 0, stdout=json.dumps(_minimal_payload(1.0)), stderr=""
        )

    monkeypatch.setattr(benchmark_module.subprocess, "run", fake_run)

    results = benchmark_module.benchmark_case_pair(
        {"base": tmp_path / "base_binary", "head": tmp_path / "head_binary"},
        name="toy",
        network_path=tmp_path / "toy.net",
        repeats=3,
        warmup_runs=2,
        iterations=1,
        flags="--silent",
    )

    # Two warmup rounds, rotating like the measured ones, then three repeats of both
    # with the lead rotating. Going first is measurably slightly more expensive, so
    # an odd repeat count leaves one binary a single extra lead -- visible here as
    # base leading rounds 1 and 3 against head leading round 2.
    assert invoked == [
        "base_binary",
        "head_binary",
        "head_binary",
        "base_binary",
        "base_binary",
        "head_binary",
        "head_binary",
        "base_binary",
        "base_binary",
        "head_binary",
    ]
    assert sorted(results) == ["base", "head"]
    for label in ("base", "head"):
        assert len(results[label]["samples"]) == 3
        assert [sample["repeat"] for sample in results[label]["run_samples"]] == [
            1,
            2,
            3,
        ]


def test_metric_stats_reports_the_minimum_sample():
    """The minimum is reported for reading a borderline verdict, not for deciding it.

    ``compare_native_benchmarks`` deliberately keeps it out of the verdict -- a
    disturbance spanning a whole measurement block moves the minimum with the median.
    """
    benchmark_module = _load_benchmark_module()

    stats = benchmark_module.metric_stats([3.0, 1.0, 2.0])

    assert stats["min"] == pytest.approx(1.0)
    assert stats["mean"] == pytest.approx(2.0)


def test_main_rejects_writing_both_reports_to_one_path(monkeypatch, tmp_path: Path):
    """Sharing the path would leave one report on disk and compare it against itself.

    The comparison would then find no difference and report no regression, which is a
    worse failure than a false alarm because nothing on screen looks wrong.
    """
    benchmark_module = _load_benchmark_module()
    shared = tmp_path / "out.json"

    import sys

    old_argv = sys.argv
    sys.argv = [
        "run_native_benchmarks.py",
        "--binary",
        "missing-binary",
        "--output",
        str(shared),
        "--compare-binary",
        "other-binary",
        "--compare-output",
        str(tmp_path / "sub" / ".." / "out.json"),
    ]
    try:
        with pytest.raises(SystemExit) as exc_info:
            benchmark_module.main()
    finally:
        sys.argv = old_argv

    assert exc_info.value.code == 2


def test_main_requires_compare_binary_and_output_together(monkeypatch, tmp_path: Path):
    """Half a comparison is a silent no-op, so the pair is validated up front."""
    benchmark_module = _load_benchmark_module()

    import sys

    old_argv = sys.argv
    sys.argv = [
        "run_native_benchmarks.py",
        "--binary",
        "missing-binary",
        "--output",
        str(tmp_path / "out.json"),
        "--compare-binary",
        "other-binary",
    ]
    try:
        with pytest.raises(SystemExit) as exc_info:
            benchmark_module.main()
    finally:
        sys.argv = old_argv

    assert exc_info.value.code == 2


def test_build_benchmark_cases_pr_profile_focuses_on_stable_cases(
    monkeypatch, tmp_path: Path
):
    benchmark_module = _load_benchmark_module()
    repo_root = Path(__file__).resolve().parents[2]
    generated_paths: list[Path] = []

    def stub_generate_state_ring(path: Path, physical_nodes: int) -> None:
        generated_paths.append(path)

    def stub_generate_sparse_graph(
        path: Path, num_nodes: int, avg_degree: int, seed: int
    ) -> None:
        generated_paths.append(path)

    def stub_generate_ring_of_cliques(
        path: Path, clique_count: int, clique_size: int
    ) -> None:
        generated_paths.append(path)

    monkeypatch.setattr(
        benchmark_module, "generate_state_ring", stub_generate_state_ring
    )
    monkeypatch.setattr(
        benchmark_module, "generate_sparse_graph", stub_generate_sparse_graph
    )
    monkeypatch.setattr(
        benchmark_module, "generate_ring_of_cliques", stub_generate_ring_of_cliques
    )

    cases = benchmark_module.build_benchmark_cases("pr", repo_root, tmp_path)
    names = [case["name"] for case in cases]
    paths = [Path(case["path"]) for case in cases]

    assert names == [
        "states_meta",
        "state_ring_5k",
        "sparse_100k",
        "ring_of_cliques_100k",
    ]
    assert paths[0] == repo_root / "examples" / "networks" / "states.net"
    assert paths[1:] == generated_paths
    assert [path.name for path in generated_paths] == [
        "state_ring_5k.net",
        "sparse_100k.net",
        "ring_of_cliques_100k.net",
    ]


def test_build_benchmark_cases_smoke_skips_100k_generation(monkeypatch, tmp_path: Path):
    benchmark_module = _load_benchmark_module()
    repo_root = _find_repo_root(Path(__file__).resolve())
    calls: list[int] = []

    original_generate_sparse_graph = benchmark_module.generate_sparse_graph

    def recording_generate_sparse_graph(
        path: Path, num_nodes: int, avg_degree: int, seed: int
    ) -> None:
        calls.append(num_nodes)
        original_generate_sparse_graph(path, num_nodes, avg_degree, seed)

    monkeypatch.setattr(
        benchmark_module, "generate_sparse_graph", recording_generate_sparse_graph
    )

    benchmark_module.build_benchmark_cases("smoke", repo_root, tmp_path)

    assert calls == [10_000]


def test_build_benchmark_cases_large_profile_uses_only_large_generated_cases(
    monkeypatch, tmp_path: Path
):
    benchmark_module = _load_benchmark_module()
    repo_root = _find_repo_root(Path(__file__).resolve())
    calls: list[tuple[str, Path, tuple[object, ...]]] = []

    def stub_generate_if_missing(path: Path, generator, *args: object) -> None:
        calls.append((generator.__name__, path, args))

    monkeypatch.setattr(
        benchmark_module, "generate_if_missing", stub_generate_if_missing
    )

    cases = benchmark_module.build_benchmark_cases("large", repo_root, tmp_path)

    assert [case["name"] for case in cases] == [
        "sparse_1m",
        "ring_of_cliques_1m",
        "block_sparse_1m",
        "state_ring_500k",
        "state_block_1m_states",
        "multilayer_100k_x10",
        "multilayer_250k_x8",
    ]
    assert [Path(case["path"]).parent for case in cases] == [tmp_path] * len(cases)
    assert [(name, path.name, args) for name, path, args in calls] == [
        ("generate_large_sparse_graph", "sparse_1m.net", (1_000_000, 10)),
        ("generate_large_ring_of_cliques", "ring_of_cliques_1m.net", (100_000, 10)),
        ("generate_block_sparse_graph", "block_sparse_1m.net", (1_000_000, 100, 8, 2)),
        ("generate_state_ring", "state_ring_500k.net", (500_000,)),
        ("generate_state_block_network", "state_block_1m_states.net", (250_000, 4, 50)),
        (
            "generate_multilayer_block_network",
            "multilayer_100k_x10.net",
            (100_000, 10, 50),
        ),
        (
            "generate_multilayer_block_network",
            "multilayer_250k_x8.net",
            (250_000, 8, 50),
        ),
    ]


def test_generate_if_missing_reuses_existing_generated_network(tmp_path: Path):
    benchmark_module = _load_benchmark_module()
    path = tmp_path / "network.net"
    path.write_text("existing\n", encoding="utf-8")
    calls = 0

    def generator(path: Path) -> None:
        nonlocal calls
        calls += 1
        path.write_text("generated\n", encoding="utf-8")

    benchmark_module.generate_if_missing(path, generator)

    assert calls == 0
    assert path.read_text(encoding="utf-8") == "existing\n"


def test_main_rejects_negative_warmup_runs(monkeypatch):
    benchmark_module = _load_benchmark_module()

    import sys

    old_argv = sys.argv
    sys.argv = [
        "run_native_benchmarks.py",
        "--binary",
        "missing-binary",
        "--output",
        "missing-output.json",
        "--warmup-runs",
        "-1",
    ]
    try:
        with pytest.raises(SystemExit) as exc_info:
            benchmark_module.main()
    finally:
        sys.argv = old_argv

    assert exc_info.value.code == 2
